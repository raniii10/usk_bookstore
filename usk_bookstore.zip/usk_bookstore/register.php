<?php
require_once 'config.php';

// Hanya user biasa yang bisa register (admin tidak bisa daftar)
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $full_name = trim($_POST['full_name']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    
    if (empty($username) || empty($email) || empty($password)) {
        $error = "Username, email, dan password wajib diisi!";
    } elseif ($password !== $confirm_password) {
        $error = "Password dan konfirmasi password tidak cocok!";
    } elseif (strlen($password) < 6) {
        $error = "Password minimal 6 karakter!";
    } else {
        // Cek username/email sudah ada
        $check = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $check->bind_param("ss", $username, $email);
        $check->execute();
        $check->store_result();
        
        if ($check->num_rows > 0) {
            $error = "Username atau email sudah terdaftar!";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // ROLE HARUS 'user' (tidak bisa pilih admin)
            $stmt = $conn->prepare("INSERT INTO users (username, email, password, full_name, phone, address, role) VALUES (?, ?, ?, ?, ?, ?, 'user')");
            $stmt->bind_param("ssssss", $username, $email, $hashed_password, $full_name, $phone, $address);
            
            if ($stmt->execute()) {
                $success = "Registrasi berhasil! Silakan login.";
                $_POST = array();
            } else {
                $error = "Registrasi gagal: " . $conn->error;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - BookStore</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .auth-container {
            max-width: 500px;
            margin: 3rem auto;
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        .auth-container h2 {
            text-align: center;
            color: #2c1810;
            margin-bottom: 1.5rem;
        }
        .form-group {
            margin-bottom: 1rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: #2c1810;
            font-weight: 500;
        }
        .form-group input, .form-group textarea {
            width: 100%;
            padding: 0.7rem;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
        }
        .btn-register {
            width: 100%;
            background: #2c1810;
            color: white;
            padding: 0.8rem;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            cursor: pointer;
            margin-top: 1rem;
        }
        .btn-register:hover {
            background: #d4a373;
            color: #2c1810;
        }
        .btn-back {
            display: inline-block;
            background: #FCB7C7;
            color: #2c1810;
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 500;
        }
        .btn-back:hover {
            background: #FFCEE3;
        }
        .error {
            background: #f8d7da;
            color: #721c24;
            padding: 0.7rem;
            border-radius: 8px;
            margin-bottom: 1rem;
        }
        .success {
            background: #d4edda;
            color: #155724;
            padding: 0.7rem;
            border-radius: 8px;
            margin-bottom: 1rem;
        }
        .login-link {
            text-align: center;
            margin-top: 1.5rem;
        }
        .login-link a {
            color: #d4a373;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <h1 class="logo">BookStore</h1>
            <a href="index.php" class="btn-back">Kembali ke Toko</a>
        </div>
    </header>

    <div class="auth-container">
        <h2>Daftar Akun Baru</h2>
        
        <?php if($error): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <?php if($success): ?>
            <div class="success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label>Username *</label>
                <input type="text" name="username" value="<?php echo $_POST['username'] ?? ''; ?>" required>
            </div>
            
            <div class="form-group">
                <label>Email *</label>
                <input type="email" name="email" value="<?php echo $_POST['email'] ?? ''; ?>" required>
            </div>
            
            <div class="form-group">
                <label>Password * (min. 6 karakter)</label>
                <input type="password" name="password" required>
            </div>
            
            <div class="form-group">
                <label>Konfirmasi Password *</label>
                <input type="password" name="confirm_password" required>
            </div>
            
            <div class="form-group">
                <label>Nama Lengkap</label>
                <input type="text" name="full_name" value="<?php echo $_POST['full_name'] ?? ''; ?>">
            </div>
            
            <div class="form-group">
                <label>No. Telepon</label>
                <input type="text" name="phone" value="<?php echo $_POST['phone'] ?? ''; ?>">
            </div>
            
            <div class="form-group">
                <label>Alamat</label>
                <textarea name="address"><?php echo $_POST['address'] ?? ''; ?></textarea>
            </div>
            
            <button type="submit" class="btn-register">Daftar</button>
        </form>
        
        <div class="login-link">
            Sudah punya akun? <a href="login.php">Login di sini</a>
        </div>
    </div>
</body>
</html>