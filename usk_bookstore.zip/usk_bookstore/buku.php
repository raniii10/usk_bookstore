<?php
require_once '../config.php';

if(!isLoggedIn() || !isAdmin()) {
    header("Location: ../login.php");
    exit();
}

// Tambah Buku
if(isset($_POST['add'])) {
    $stmt = $conn->prepare("INSERT INTO books (title, author, original_price, discounted_price, category, is_bestseller) VALUES (?,?,?,?,?,?)");
    $stmt->bind_param("ssddsi", $_POST['title'], $_POST['author'], $_POST['original_price'], $_POST['discounted_price'], $_POST['category'], isset($_POST['is_bestseller'])?1:0);
    $stmt->execute();
    header("Location: buku.php");
    exit();
}

// Edit Buku
if(isset($_POST['edit'])) {
    $stmt = $conn->prepare("UPDATE books SET title=?, author=?, original_price=?, discounted_price=?, category=?, is_bestseller=? WHERE id=?");
    $stmt->bind_param("ssddsii", $_POST['title'], $_POST['author'], $_POST['original_price'], $_POST['discounted_price'], $_POST['category'], isset($_POST['is_bestseller'])?1:0, $_POST['id']);
    $stmt->execute();
    header("Location: buku.php");
    exit();
}

// Hapus Buku
if(isset($_GET['delete'])) {
    $conn->query("DELETE FROM books WHERE id = ".$_GET['delete']);
    header("Location: buku.php");
    exit();
}

$books = $conn->query("SELECT * FROM books ORDER BY id DESC");
$categories = $conn->query("SELECT * FROM categories");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Buku - Admin</title>
    <link rel="stylesheet" href="../style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #f5f7fa; }
        .sidebar { position: fixed; left: 0; top: 0; width: 260px; height: 100%; background: #1a1a2e; color: white; padding: 1.5rem; }
        .sidebar .logo { font-size: 1.5rem; font-weight: bold; margin-bottom: 2rem; text-align: center; }
        .sidebar .logo span { color: #e94560; }
        .sidebar .search { background: rgba(255,255,255,0.1); border-radius: 8px; padding: 0.5rem 1rem; margin-bottom: 1.5rem; }
        .sidebar .search input { background: none; border: none; color: white; width: 100%; outline: none; }
        .sidebar .user-info { display: flex; align-items: center; gap: 0.8rem; margin-bottom: 1.5rem; padding-bottom: 1rem; border-bottom: 1px solid rgba(255,255,255,0.1); }
        .sidebar .avatar { width: 45px; height: 45px; background: #e94560; border-radius: 50%; display: flex; align-items: center; justify-content: center; }
        .sidebar nav a { display: block; padding: 0.7rem 1rem; color: rgba(255,255,255,0.7); text-decoration: none; border-radius: 8px; margin-bottom: 0.3rem; }
        .sidebar nav a:hover, .sidebar nav a.active { background: #e94560; color: white; }
        .main-content { margin-left: 260px; padding: 1.5rem; }
        .top-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; }
        .top-bar h1 { font-size: 1.8rem; color: #1a1a2e; }
        .logout-btn { background: #e94560; color: white; padding: 0.5rem 1rem; border-radius: 8px; text-decoration: none; }
        .section-card { background: white; border-radius: 15px; padding: 1.5rem; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        .section-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; }
        .btn-add { background: #e94560; color: white; padding: 0.5rem 1rem; border: none; border-radius: 8px; cursor: pointer; }
        .btn-edit { background: #ffc107; color: #1a1a2e; padding: 0.3rem 0.8rem; border: none; border-radius: 5px; cursor: pointer; margin-right: 0.3rem; }
        .btn-delete { background: #dc3545; color: white; padding: 0.3rem 0.8rem; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 0.75rem; text-align: left; border-bottom: 1px solid #eee; }
        th { color: #666; font-weight: 600; }
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; }
        .modal-content { background: white; max-width: 500px; margin: 3rem auto; padding: 1.5rem; border-radius: 15px; }
        .modal-content input, .modal-content select { width: 100%; padding: 0.5rem; margin: 0.5rem 0; border: 1px solid #ddd; border-radius: 5px; }
        .close { float: right; font-size: 1.5rem; cursor: pointer; }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo">Book<span>Store</span></div>
        <div class="search"><input type="text" placeholder="Search here..."></div>
        <div class="user-info">
            <div class="avatar">👤</div>
            <div class="user-text"><h4><?php echo $_SESSION['full_name']; ?></h4><p>Super Admin</p></div>
        </div>
        <nav>
            <a href="dashboard.php">📊 Dashboard</a>
            <a href="kategori.php">📁 Kategori</a>
            <a href="buku.php" class="active">📚 Buku</a>
            <a href="dashboard.php#user">👥 User</a>
            <a href="dashboard.php#pesanan">📦 Pesanan</a>
        </nav>
    </div>

    <div class="main-content">
        <div class="top-bar">
            <h1>Kelola Buku</h1>
            <a href="../logout.php" class="logout-btn">Logout</a>
        </div>

        <div class="section-card">
            <div class="section-header">
                <h2>📚 Daftar Buku</h2>
                <button class="btn-add" onclick="openModal('addModal')">+ Tambah Buku</button>
            </div>
            <div style="overflow-x:auto">
                <table>
                    <thead><tr><th>ID</th><th>Judul</th><th>Penulis</th><th>Kategori</th><th>Harga Asli</th><th>Harga Diskon</th><th>Bestseller</th><th>Aksi</th></tr></thead>
                    <tbody>
                        <?php while($row = $books->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo $row['title']; ?></td>
                            <td><?php echo $row['author']; ?></td>
                            <td><?php echo $row['category']; ?></td>
                            <td>Rp <?php echo number_format($row['original_price'],0,',','.'); ?></td>
                            <td>Rp <?php echo number_format($row['discounted_price'],0,',','.'); ?></td>
                            <td><?php echo $row['is_bestseller'] ? '✅' : '❌'; ?></td>
                            <td>
                                <button class="btn-edit" onclick="editBuku(<?php echo htmlspecialchars(json_encode($row)); ?>)">Edit</button>
                                <a href="?delete=<?php echo $row['id']; ?>" class="btn-delete" onclick="return confirm('Yakin hapus?')">Hapus</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- MODAL TAMBAH -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('addModal')">&times;</span>
            <h3>Tambah Buku</h3>
            <form method="POST">
                <input type="text" name="title" placeholder="Judul Buku" required>
                <input type="text" name="author" placeholder="Penulis" required>
                <input type="number" name="original_price" placeholder="Harga Asli" required>
                <input type="number" name="discounted_price" placeholder="Harga Diskon" required>
                <select name="category" required>
                    <option value="">Pilih Kategori</option>
                    <?php $cats = $conn->query("SELECT * FROM categories"); while($c=$cats->fetch_assoc()){ echo "<option value='{$c['name']}'>{$c['name']}</option>"; } ?>
                </select>
                <label><input type="checkbox" name="is_bestseller"> Bestseller</label>
                <button type="submit" name="add">Simpan</button>
            </form>
        </div>
    </div>

    <!-- MODAL EDIT -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('editModal')">&times;</span>
            <h3>Edit Buku</h3>
            <form method="POST" id="editForm">
                <input type="hidden" name="id" id="edit_id">
                <input type="text" name="title" id="edit_title" required>
                <input type="text" name="author" id="edit_author" required>
                <input type="number" name="original_price" id="edit_original_price" required>
                <input type="number" name="discounted_price" id="edit_discounted_price" required>
                <select name="category" id="edit_category">
                    <?php $cats2 = $conn->query("SELECT * FROM categories"); while($c=$cats2->fetch_assoc()){ echo "<option value='{$c['name']}'>{$c['name']}</option>"; } ?>
                </select>
                <label><input type="checkbox" name="is_bestseller" id="edit_bestseller"> Bestseller</label>
                <button type="submit" name="edit">Update</button>
            </form>
        </div>
    </div>

    <script>
        function openModal(id) { document.getElementById(id).style.display = 'block'; }
        function closeModal(id) { document.getElementById(id).style.display = 'none'; }
        function editBuku(book) {
            document.getElementById('edit_id').value = book.id;
            document.getElementById('edit_title').value = book.title;
            document.getElementById('edit_author').value = book.author;
            document.getElementById('edit_original_price').value = book.original_price;
            document.getElementById('edit_discounted_price').value = book.discounted_price;
            document.getElementById('edit_category').value = book.category;
            document.getElementById('edit_bestseller').checked = book.is_bestseller == 1;
            openModal('editModal');
        }
        window.onclick = function(e) { if(e.target.classList.contains('modal')) e.target.style.display = 'none'; }
    </script>
</body>
</html>