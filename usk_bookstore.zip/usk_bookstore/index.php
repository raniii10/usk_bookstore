<?php
require_once 'config.php';

// Ambil semua data buku
$bestseller = $conn->query("SELECT * FROM books WHERE is_bestseller = TRUE ORDER BY id ASC LIMIT 4");
$fiksi = $conn->query("SELECT * FROM books WHERE category = 'Fiksi' ORDER BY id ASC LIMIT 8");
$nonfiksi = $conn->query("SELECT * FROM books WHERE category = 'Non Fiksi' ORDER BY id ASC LIMIT 8");
$pendidikan = $conn->query("SELECT * FROM books WHERE category = 'Pendidikan' ORDER BY id ASC LIMIT 8");

// Fungsi untuk mendapatkan gambar cover dari internet
function getCoverImage($title) {
    // Gambar placeholder yang bagus dari Unsplash
    $images = [
        'Hujan' => 'hujan.jpg',
        'Laskar Pelangi' => 'laskar pelangi.jpg', 
        'Bumi' => 'bumi.jpg',
        'Dilan' => 'dilan.jpg',
        'Tentang Kamu' => 'tentang kamu.jpg',
        'Komet Minor' => 'komet minor.jpg',
        'Negeri 5 Menara' => 'negeri 5 menara.jpg',
        'Perahu Kertas' => 'perahu kertas.jpg',
        'Sapiens' => 'sapiens.jpg',
        'Atomic Habits' => 'atomic habits.jpg',
        'Filosofi Teras' => 'filosofi teras.jpg',
        'Seni Hidup Minimalis' => 'seni hidup minimalis.jpg',
        'The Psychology of Money' => 'the psychology of money.jpg',
        'Think and Grow Rich' => 'think and grow rich.jpg',
        'The Subtle Art' => 'the subtle art.jpg',
        'Deep Work' => 'deep work.jpg',
        'Matematika SMA Kelas 12' => 'matematika sma kelas 12.jpg',
        'Fisika Dasar' => 'fisika dasar.jpg',
        'Kimia untuk Universitas' => 'kimia untuk universitas.jpg',
        'Bahasa Inggris Profesional' => 'bahasa inggris profesional.jpg',
        'Pemrograman Web' => 'pemrograman web.jpg',
        'Desain Grafis' => 'desain grafis.jpg',
        'Basis Data' => 'basis data.jpg',
        'Jaringan Komputer' => 'jaringan komputer.jpg',
    ];
    
    return isset($images[$title]) ? $images[$title] : 'perpus.jpg';
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BookStore</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <section id="home" class="section-home">
        <header>
            <div class="header-container">
                <h1 class="logo">BookStore</h1>
                <div class="search-bar">
                    <input type="text" id="searchInput" placeholder="Cari buku...">
                    <button id="searchBtn">Cari</button>
                </div>
                <div class="header-right">
                    <a href="cart.php" class="cart-icon">🛒 <span id="cartCount">0</span></a>
                    <?php if(isLoggedIn()): ?>
                        <div class="user-menu">
                            <span class="user-name"><?php echo htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username']); ?></span>
                            <div class="dropdown-user">
                                <a href="logout.php">Logout</a>
                            </div>
                        </div>
                    <?php else: ?>
                        <a href="login.php" class="login-btn">Login</a>
                        <a href="register.php" class="register-btn">Daftar</a>
                    <?php endif; ?>
                </div>
            </div>
        </header>

        <nav>
            <ul>
                <li><a href="#home">Home</a></li>
                <li class="dropdown">
                    <a href="#">Kategori ▼</a>
                    <div class="dropdown-content">
                        <a href="#fiksi">Fiksi</a>
                        <a href="#nonfiksi">Non Fiksi</a>
                        <a href="#pendidikan">Pendidikan</a>
                    </div>
                </li>
                <li><a href="#tentang">Tentang Kami</a></li>
                <li><a href="#kontak">Kontak</a></li>
            </ul>
        </nav>

        <div class="hero">
            <div class="hero-container">
                <div class="hero-text">
                    <h1>Masuki dunia cerita penuh imajinasi</h1>
                    <p>Koleksi buku pilihan yang seru, menghibur, dan menginspirasi</p>
                </div>
                <div class="hero-image">
                    <img src="perpus.jpg" alt="Buku">
                </div>
            </div>
        </div>
</nav>

<!-- BESTSELLER -->
<div class="container">
    <div class="section-title"><h2>⭐ Buku Bestseller</h2></div>
    <div class="books-grid">
        ...
    </div>
</div>
       
            <div class="books-grid">
                <?php while($book = $bestseller->fetch_assoc()): ?>
                <div class="book-card" data-title="<?php echo strtolower($book['title']); ?>">
                    <div class="bestseller-badge">BESTSELLER</div>
                    <div class="book-frame">
                        <img src="<?php echo getCoverImage($book['title']); ?>" class="book-cover-img">
                    </div>
                    <h3><?php echo $book['title']; ?></h3>
                    <p class="author"><?php echo $book['author']; ?></p>
                    <p class="price">
                        <span class="original">Rp <?php echo number_format($book['original_price'], 0, ',', '.'); ?></span>
                        <span class="discounted">Rp <?php echo number_format($book['discounted_price'], 0, ',', '.'); ?></span>
                    </p>
                    <div class="book-actions">
                        <button class="add-to-cart" data-id="<?php echo $book['id']; ?>">Add to Cart</button>
                        <button class="checkout-btn" data-id="<?php echo $book['id']; ?>">Checkout</button>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
    </section>

    <section id="fiksi" class="section">
        <div class="container">
            <div class="section-title">
                <h2>📖 Buku Fiksi</h2>
            </div>
            <div class="books-grid">
                <?php while($book = $fiksi->fetch_assoc()): ?>
                <div class="book-card" data-title="<?php echo strtolower($book['title']); ?>">
                    <div class="book-frame">
                        <img src="<?php echo getCoverImage($book['title']); ?>" class="book-cover-img">
                    </div>
                    <h3><?php echo $book['title']; ?></h3>
                    <p class="author"><?php echo $book['author']; ?></p>
                    <p class="price">
                        <span class="original">Rp <?php echo number_format($book['original_price'], 0, ',', '.'); ?></span>
                        <span class="discounted">Rp <?php echo number_format($book['discounted_price'], 0, ',', '.'); ?></span>
                    </p>
                    <div class="book-actions">
                        <button class="add-to-cart" data-id="<?php echo $book['id']; ?>">Add to Cart</button>
                        <button class="checkout-btn" data-id="<?php echo $book['id']; ?>">Checkout</button>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
    </section>

    <section id="nonfiksi" class="section">
        <div class="container">
            <div class="section-title">
                <h2>📚 Buku Non Fiksi</h2>
            </div>
            <div class="books-grid">
                <?php while($book = $nonfiksi->fetch_assoc()): ?>
                <div class="book-card" data-title="<?php echo strtolower($book['title']); ?>">
                    <div class="book-frame">
                        <img src="<?php echo getCoverImage($book['title']); ?>" class="book-cover-img">
                    </div>
                    <h3><?php echo $book['title']; ?></h3>
                    <p class="author"><?php echo $book['author']; ?></p>
                    <p class="price">
                        <span class="original">Rp <?php echo number_format($book['original_price'], 0, ',', '.'); ?></span>
                        <span class="discounted">Rp <?php echo number_format($book['discounted_price'], 0, ',', '.'); ?></span>
                    </p>
                    <div class="book-actions">
                        <button class="add-to-cart" data-id="<?php echo $book['id']; ?>">Add to Cart</button>
                        <button class="checkout-btn" data-id="<?php echo $book['id']; ?>">Checkout</button>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
    </section>

    <section id="pendidikan" class="section">
        <div class="container">
            <div class="section-title">
                <h2>🎓 Buku Pendidikan</h2>
            </div>
            <div class="books-grid">
                <?php while($book = $pendidikan->fetch_assoc()): ?>
                <div class="book-card" data-title="<?php echo strtolower($book['title']); ?>">
                    <div class="book-frame">
                        <img src="<?php echo getCoverImage($book['title']); ?>" class="book-cover-img">
                    </div>
                    <h3><?php echo $book['title']; ?></h3>
                    <p class="author"><?php echo $book['author']; ?></p>
                    <p class="price">
                        <span class="original">Rp <?php echo number_format($book['original_price'], 0, ',', '.'); ?></span>
                        <span class="discounted">Rp <?php echo number_format($book['discounted_price'], 0, ',', '.'); ?></span>
                    </p>
                    <div class="book-actions">
                        <button class="add-to-cart" data-id="<?php echo $book['id']; ?>">Add to Cart</button>
                        <button class="checkout-btn" data-id="<?php echo $book['id']; ?>">Checkout</button>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
    </section>

    <section id="tentang" class="section">
        <div class="container">
            <div class="section-title">
                <h2>Tentang BookStore</h2>
                <p class="subtitle">Kenali lebih dekat toko buku online favoritmu</p>
            </div>
            <div class="tentang-content">
                <div class="tentang-box">
                    <h3>📖 Siapa Kami?</h3>
                    <p>BookStore adalah toko buku online yang berdiri sejak 2020. Kami berkomitmen untuk menyediakan buku-buku berkualitas dengan harga terbaik. Kami percaya bahwa membaca adalah jendela dunia, dan setiap orang berhak memiliki akses ke buku-buku bagus yang dapat menginspirasi, menghibur, dan menambah wawasan.</p>
                </div>
                <div class="tentang-box">
                    <h3>🎯 Misi Kami</h3>
                    <p>Menyediakan koleksi buku terbaik dengan harga terjangkau untuk seluruh pembaca di Indonesia. Kami ingin menumbuhkan minat baca masyarakat dan menjadi mitra terbaik dalam perjalanan literasi Anda.</p>
                </div>
                <div class="tentang-box">
                    <h3>🌟 Visi Kami</h3>
                    <p>Menjadi toko buku online terpercaya nomor 1 di Indonesia yang menginspirasi generasi pembaca cerdas dan berwawasan luas.</p>
                </div>
            </div>
        </div>
    </section>

       <!-- KONTAK (sudah ada) -->
    <div id="kontak" class="container">
        <div class="section-title"><h2>📞 Kontak Kami</h2></div>
        <div style="text-align:center;">
            <p>Email: info@bookstore.com</p>
            <p>Telepon: 0812-3456-7890</p>
            <p>Alamat: Jl. Buku No. 123</p>
        </div>
    </div>



        <!-- KONTAK -->
    <div id="kontak" class="container">...</div>


    <script src="script.js"></script>
</body>
</html>

    <script>
        function updateCartCount() {
            fetch('cart_count.php').then(res=>res.json()).then(data=>{
                document.getElementById('cartCount').innerText = data.count || 0;
            });
        }
        updateCartCount();

        // SEARCH
        document.getElementById('searchBtn').onclick = function() {
            let keyword = document.getElementById('searchInput').value.toLowerCase();
            document.querySelectorAll('.book-card').forEach(card => {
                let title = card.getAttribute('data-title');
                card.style.display = title && title.includes(keyword) ? 'block' : 'none';
            });
        };

        document.getElementById('searchInput').onkeyup = function(e) {
            if(e.key === 'Enter') {
                let keyword = this.value.toLowerCase();
                document.querySelectorAll('.book-card').forEach(card => {
                    let title = card.getAttribute('data-title');
                    card.style.display = title && title.includes(keyword) ? 'block' : 'none';
                });
            }
            if(this.value === '') {
                document.querySelectorAll('.book-card').forEach(card => card.style.display = 'block');
            }
        };

        // ADD TO CART
        document.querySelectorAll('.add-to-cart').forEach(btn => {
            btn.onclick = function() {
                fetch('add_to_cart.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'book_id=' + this.dataset.id
                }).then(res=>res.json()).then(data=>{
                    if(data.success) {
                        updateCartCount();
                        alert('Buku ditambahkan ke keranjang');
                    } else {
                        alert('Silakan login dulu');
                        window.location.href = 'login.php';
                    }
                });
            }
        });

        // CHECKOUT
        document.querySelectorAll('.checkout-btn').forEach(btn => {
            btn.onclick = function() {
                fetch('add_to_cart.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'book_id=' + this.dataset.id
                }).then(() => {
                    window.location.href = 'cart.php';
                });
            }
        });
    </script>
</body>
</html>