<?php
require_once 'config.php';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tentang Kami - BookStore</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .about-page {
            max-width: 1000px;
            margin: 3rem auto;
            padding: 0 1rem;
        }
        .about-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        .about-header h1 {
            font-size: 2rem;
            color: #2c1810;
            margin-bottom: 0.5rem;
        }
        .about-header p {
            color: #8b5e3c;
        }
        .about-card {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .about-card h2 {
            color: #2c1810;
            margin-bottom: 1rem;
            border-left: 4px solid #FCB7C7;
            padding-left: 1rem;
        }
        .about-card p {
            line-height: 1.8;
            color: #444;
        }
        .about-card ul {
            padding-left: 1.5rem;
            line-height: 1.8;
        }
        .about-card ul li {
            margin: 0.5rem 0;
            color: #444;
        }
        .stats {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            gap: 1rem;
            margin-top: 1rem;
        }
        .stat {
            text-align: center;
            flex: 1;
            min-width: 100px;
            padding: 1rem;
            background: #f5f0e8;
            border-radius: 10px;
        }
        .stat-number {
            font-size: 2rem;
            font-weight: bold;
            color: #FCB7C7;
        }
        .stat-label {
            color: #8b5e3c;
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <h1 class="logo">BookStore</h1>
            <div class="search-bar">
                <input type="text" id="searchInput" placeholder="Search books...">
                <button>Cari</button>
            </div>
            <div class="header-right">
                <a href="cart.php" class="cart-icon">🛒 <span id="cartCount">0</span></a>
                <?php if(isLoggedIn()): ?>
                    <div class="user-menu">
                        <span class="user-name"><?php echo htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username']); ?></span>
                        <div class="dropdown-user">
                            <?php if(isAdmin()): ?>
                                <a href="admin/dashboard.php">Admin Panel</a>
                            <?php endif; ?>
                            <a href="profile.php">Profil Saya</a>
                            <a href="logout.php">Logout</a>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="login.php" class="login-btn">Login</a>
                    <a href="register.php" class="register-btn">Daftar</a>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li class="dropdown">
                <a href="javascript:void(0)" class="dropbtn">Kategori ▼</a>
                <div class="dropdown-content">
                    <a href="fiksi.php">Fiksi</a>
                    <a href="nonfiksi.php">Non Fiksi</a>
                    <a href="pendidikan.php">Pendidikan</a>
                </div>
            </li>
            <li><a href="about.php" class="active">Tentang Kami</a></li>
            <li><a href="contact.php">Kontak</a></li>
        </ul>
    </nav>

    <div class="about-page">
        <div class="about-header">
            <h1>📖 Tentang BookStore</h1>
            <p>Kenali lebih dekat toko buku online favoritmu</p>
        </div>

        <div class="about-card">
            <h2>Siapa Kami?</h2>
            <p>BookStore adalah toko buku online yang berdiri sejak 2020. Kami berkomitmen untuk menyediakan buku-buku berkualitas dengan harga terbaik. Kami percaya bahwa membaca adalah jendela dunia, dan setiap orang berhak memiliki akses ke buku-buku bagus yang dapat menginspirasi, menghibur, dan menambah wawasan.</p>
        </div>

        <div class="about-card">
            <h2>Misi Kami</h2>
            <p>Menyediakan koleksi buku terbaik dengan harga terjangkau untuk seluruh pembaca di Indonesia. Kami ingin menumbuhkan minat baca masyarakat dan menjadi mitra terbaik dalam perjalanan literasi Anda.</p>
        </div>

        <div class="about-card">
            <h2>Visi Kami</h2>
            <p>Menjadi toko buku online terpercaya nomor 1 di Indonesia yang menginspirasi generasi pembaca cerdas dan berwawasan luas.</p>
        </div>

        <div class="about-card">
            <h2>Mengapa Memilih BookStore?</h2>
            <ul>
                <li>✅ Buku original 100%</li>
                <li>✅ Harga diskon setiap hari</li>
                <li>✅ Pengiriman cepat ke seluruh Indonesia</li>
                <li>✅ Garansi uang kembali jika buku cacat</li>
                <li>✅ Customer service ramah 24/7</li>
                <li>✅ Free packaging bubble wrap</li>
            </ul>
        </div>

        <div class="about-card">
            <h2>Statistik Kami</h2>
            <div class="stats">
                <div class="stat">
                    <div class="stat-number">5000+</div>
                    <div class="stat-label">Buku Terjual</div>
                </div>
                <div class="stat">
                    <div class="stat-number">2000+</div>
                    <div class="stat-label">Pelanggan Puas</div>
                </div>
                <div class="stat">
                    <div class="stat-number">1000+</div>
                    <div class="stat-label">Judul Buku</div>
                </div>
                <div class="stat">
                    <div class="stat-number">4.9</div>
                    <div class="stat-label">Rating</div>
                </div>
            </div>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 BookStore. All rights reserved.</p>
    </footer>

    <script>
        function updateCartCount() {
            fetch('cart_count.php')
                .then(res => res.json())
                .then(data => {
                    document.getElementById('cartCount').innerText = data.count || 0;
                });
        }
        updateCartCount();
    </script>
</body>
</html>