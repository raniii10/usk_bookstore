<?php
require_once 'config.php';

$result = $conn->query("SELECT SUM(quantity) as total FROM cart");
$row = $result->fetch_assoc();
$count = $row['total'] ?? 0;

echo json_encode(['count' => $count]);
?>