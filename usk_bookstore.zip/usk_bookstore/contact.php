<!DOCTYPE html>
<html>
<head>
    <title>Kontak Kami</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .contact-page {
            max-width: 1000px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        .contact-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        .contact-header h1 {
            font-size: 2rem;
            color: #2c1810;
        }
        .contact-row {
            display: flex;
            justify-content: center;
            gap: 1.5rem;
            flex-wrap: wrap;
            margin-bottom: 2rem;
        }
        .contact-card {
            background: white;
            padding: 1.5rem;
            border-radius: 12px;
            text-align: center;
            width: 220px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: 0.3s;
        }
        .contact-card:hover {
            transform: translateY(-5px);
        }
        .contact-icon {
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
        }
        .contact-card h3 {
            font-size: 1.1rem;
            color: #2c1810;
            margin-bottom: 0.5rem;
        }
        .contact-card a {
            display: inline-block;
            background: #FCB7C7;
            color: #2c1810;
            padding: 0.5rem 1rem;
            border-radius: 25px;
            text-decoration: none;
            font-size: 0.85rem;
            margin-top: 0.5rem;
        }
        .contact-card a:hover {
            background: #FFCEE3;
        }
        .contact-card p {
            color: #666;
            font-size: 0.85rem;
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <h1 class="logo">BookStore</h1>
            <div class="search-bar">
                <input type="text" id="searchInput" placeholder="Cari buku...">
                <button>🔍</button>
            </div>
            <div class="header-right">
                <a href="cart.php" class="cart-icon">🛒 <span id="cartCount">0</span></a>
                <?php if(isLoggedIn()): ?>
                    <div class="user-menu">
                        <span class="user-name"><?php echo $_SESSION['username']; ?></span>
                        <div class="dropdown-user">
                            <a href="logout.php">Logout</a>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="login.php" class="login-btn">Login</a>
                    <a href="register.php" class="register-btn">Daftar</a>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li class="dropdown">
                <a href="#">Kategori ▼</a>
                <div class="dropdown-content">
                    <a href="fiksi.php">Fiksi</a>
                    <a href="nonfiksi.php">Non Fiksi</a>
                    <a href="pendidikan.php">Pendidikan</a>
                </div>
            </li>
            <li><a href="about.php">Tentang Kami</a></li>
            <li><a href="contact.php" class="active">Kontak</a></li>
        </ul>
    </nav>

    <div class="contact-page">
        <div class="contact-header">
            <h1>Hubungi Kami</h1>
        </div>

        <div class="contact-row">
            <div class="contact-card">
                <div class="contact-icon">💬</div>
                <h3>WhatsApp</h3>
                <p>Chat dengan admin</p>
                <a href="https://wa.me/6281234567890" target="_blank">Kirim Pesan</a>
            </div>

            <div class="contact-card">
                <div class="contact-icon">📷</div>
                <h3>Instagram</h3>
                <p>Follow kami</p>
                <a href="https://www.instagram.com/" target="_blank">@bookstore</a>
            </div>

            <div class="contact-card">
                <div class="contact-icon">✉️</div>
                <h3>Email</h3>
                <p>Kirim email</p>
                <a href="mailto:info@bookstore.com">info@bookstore.com</a>
            </div>
        </div>

        <div style="text-align: center; margin-top: 1rem;">
            <p>📍 Alamat: Jl. Buku No. 123, Kota Baca</p>
            <a href="index.php">← Kembali ke Home</a>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 BookStore. All rights reserved.</p>
    </footer>

    <script>
        function updateCartCount() {
            fetch('cart_count.php').then(res=>res.json()).then(data=>{
                document.getElementById('cartCount').innerText = data.count || 0;
            });
        }
        updateCartCount();
    </script>
</body>
</html>