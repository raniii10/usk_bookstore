<?php
require_once 'config.php';
requireLogin();

$user_id = $_SESSION['user_id'];

$user_query = $conn->prepare("SELECT * FROM users WHERE id = ?");
$user_query->bind_param("i", $user_id);
$user_query->execute();
$user = $user_query->get_result()->fetch_assoc();

$cart_query = $conn->prepare("
    SELECT cart.id as cart_id, cart.quantity, books.* 
    FROM cart 
    JOIN books ON cart.book_id = books.id 
    WHERE cart.user_id = ?
");
$cart_query->bind_param("i", $user_id);
$cart_query->execute();
$cart_items = $cart_query->get_result();

$subtotal = 0;
$items = [];
while($item = $cart_items->fetch_assoc()) {
    $subtotal += $item['discounted_price'] * $item['quantity'];
    $items[] = $item;
}

if (empty($items)) {
    header("Location: index.php");
    exit();
}

$delivery_cost = 20000;
$total = $subtotal + $delivery_cost;
$invoice_number = 'INV-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $payment_method = $_POST['payment_method'];
    $full_name = $_POST['full_name'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    
    $insert_order = $conn->prepare("
        INSERT INTO orders (order_number, user_id, total_amount, shipping_cost, grand_total, shipping_address, phone, payment_method, status, created_at) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', NOW())
    ");
    $insert_order->bind_param("siiddsss", $invoice_number, $user_id, $subtotal, $delivery_cost, $total, $address, $phone, $payment_method);
    
    if ($insert_order->execute()) {
        $order_id = $conn->insert_id;
        
        foreach ($items as $item) {
            $sub = $item['discounted_price'] * $item['quantity'];
            $insert_detail = $conn->prepare("
                INSERT INTO order_details (order_id, book_id, book_title, book_author, price, quantity, subtotal) 
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $insert_detail->bind_param("iissdid", $order_id, $item['id'], $item['title'], $item['author'], $item['discounted_price'], $item['quantity'], $sub);
            $insert_detail->execute();
        }
        
        $clear_cart = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
        $clear_cart->bind_param("i", $user_id);
        $clear_cart->execute();
        
        if ($payment_method == 'Bank Transfer') {
            header("Location: transfer_success.php?order_id=" . $order_id);
        } else {
            header("Location: order_success.php?order_id=" . $order_id);
        }
        exit();
    } else {
        $error = "Gagal memproses pesanan.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment - BookStore</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .payment-container {
            max-width: 1000px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        .payment-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
        }
        .bill-summary, .payment-form {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .bill-summary h2, .payment-form h2 {
            color: #2c1810;
            margin-bottom: 1rem;
            border-left: 4px solid #FCB7C7;
            padding-left: 1rem;
        }
        .bill-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 1rem;
            color: #666;
            font-size: 0.85rem;
        }
        .bill-table {
            width: 100%;
            border-collapse: collapse;
        }
        .bill-table th, .bill-table td {
            padding: 0.5rem;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        .bill-table th {
            color: #666;
        }
        .bill-total {
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 1px solid #ddd;
        }
        .bill-row {
            display: flex;
            justify-content: space-between;
            padding: 0.3rem 0;
        }
        .bill-row.total {
            font-size: 1.2rem;
            font-weight: bold;
            color: #c0392b;
            border-top: 1px solid #ddd;
            margin-top: 0.3rem;
            padding-top: 0.5rem;
        }
        .form-group {
            margin-bottom: 1rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: #2c1810;
            font-weight: 500;
        }
        .form-group input, .form-group textarea {
            width: 100%;
            padding: 0.7rem;
            border: 1px solid #ddd;
            border-radius: 8px;
        }
        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }
        .payment-options {
            display: flex;
            flex-direction: column;
            gap: 0.8rem;
            margin: 1rem 0;
        }
        .payment-card {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 0.8rem;
            cursor: pointer;
            transition: 0.3s;
        }
        .payment-card:hover {
            border-color: #FCB7C7;
            background: #f5f0e8;
        }
        .payment-card input {
            margin-right: 0.8rem;
        }
        .btn-pay {
            width: 100%;
            background: #FCB7C7;
            color: #2c1810;
            padding: 0.8rem;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
            margin-top: 1rem;
        }
        .btn-pay:hover {
            background: #FFCEE3;
        }
        .error-msg {
            background: #f8d7da;
            color: #721c24;
            padding: 0.5rem;
            border-radius: 5px;
            margin-bottom: 1rem;
        }
        @media (max-width: 768px) {
            .payment-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <h1 class="logo">BookStore</h1>
            <a href="cart.php" style="color:#2c1810; text-decoration:none;">← Back to Cart</a>
        </div>
    </header>

    <div class="payment-container">
        <div class="payment-grid">
            <div class="bill-summary">
                <h2>Bill Summary</h2>
                <div class="bill-header">
                    <span>Invoice: <?php echo $invoice_number; ?></span>
                    <span><?php echo date('d F Y'); ?></span>
                </div>
                <table class="bill-table">
                    <thead><tr><th>Item</th><th>Qty</th><th>Price</th><th>Total</th></tr></thead>
                    <tbody>
                        <?php foreach($items as $item): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['title']); ?><br><small><?php echo htmlspecialchars($item['author']); ?></small></td>
                            <td><?php echo $item['quantity']; ?></td>
                            <td>Rp <?php echo number_format($item['discounted_price'], 0, ',', '.'); ?></td>
                            <td>Rp <?php echo number_format($item['discounted_price'] * $item['quantity'], 0, ',', '.'); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <div class="bill-total">
                    <div class="bill-row"><span>Subtotal</span><span>Rp <?php echo number_format($subtotal, 0, ',', '.'); ?></span></div>
                    <div class="bill-row"><span>Delivery</span><span>Rp <?php echo number_format($delivery_cost, 0, ',', '.'); ?></span></div>
                    <div class="bill-row total"><span>Total</span><span>Rp <?php echo number_format($total, 0, ',', '.'); ?></span></div>
                </div>
            </div>

            <div class="payment-form">
                <h2>Payment Method</h2>
                <?php if(isset($error)): ?>
                    <div class="error-msg"><?php echo $error; ?></div>
                <?php endif; ?>
                <form method="POST">
                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" name="full_name" required value="<?php echo htmlspecialchars($user['full_name'] ?? $user['username']); ?>">
                    </div>
                    <div class="form-group">
                        <label>Phone Number</label>
                        <input type="text" name="phone" required value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label>Shipping Address</label>
                        <textarea name="address" required rows="3"><?php echo htmlspecialchars($user['address'] ?? ''); ?></textarea>
                    </div>
                    
                    <div class="payment-options">
                        <label class="payment-card">
                            <input type="radio" name="payment_method" value="Bank Transfer" required> 🏦 Bank Transfer
                        </label>
                        <label class="payment-card">
                            <input type="radio" name="payment_method" value="COD"> 🚚 COD (Cash on Delivery)
                        </label>
                    </div>
                    
                    <button type="submit" class="btn-pay">Confirm & Pay</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>