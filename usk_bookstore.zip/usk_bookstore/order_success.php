<?php
require_once 'config.php';
requireLogin();

$order_id = isset($_GET['order_id']) ? $_GET['order_id'] : 0;

$order_query = $conn->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
$order_query->bind_param("ii", $order_id, $_SESSION['user_id']);
$order_query->execute();
$order = $order_query->get_result()->fetch_assoc();

if (!$order) {
    header("Location: index.php");
    exit();
}

$details_query = $conn->prepare("SELECT * FROM order_details WHERE order_id = ?");
$details_query->bind_param("i", $order_id);
$details_query->execute();
$details = $details_query->get_result();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Success - BookStore</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .order-success-container {
            max-width: 800px;
            margin: 3rem auto;
            background: white;
            border-radius: 15px;
            padding: 2rem;
            text-align: center;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        .success-icon {
            font-size: 4rem;
            margin-bottom: 1rem;
        }
        .order-success-container h1 {
            color: #28a745;
            margin-bottom: 0.5rem;
        }
        .order-success-container p {
            color: #666;
            margin-bottom: 1.5rem;
        }
        .order-box {
            background: #f5f0e8;
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 1.5rem;
            text-align: left;
        }
        .order-row {
            display: flex;
            justify-content: space-between;
            padding: 0.5rem 0;
            border-bottom: 1px solid #ddd;
        }
        .order-row:last-child {
            border-bottom: none;
        }
        .btn-home-success {
            display: inline-block;
            background: #FCB7C7;
            color: #2c1810;
            padding: 0.8rem 2rem;
            text-decoration: none;
            border-radius: 25px;
            margin-top: 1rem;
        }
        .btn-home-success:hover {
            background: #FFCEE3;
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <h1 class="logo">BookStore</h1>
        </div>
    </header>

    <div class="order-success-container">
        <div class="success-icon">✅</div>
        <h1>Pesanan Berhasil!</h1>
        <p>Pesanan Anda sedang kami proses</p>
        
        <div class="order-box">
            <div class="order-row">
                <span>Nomor Pesanan</span>
                <strong><?php echo $order['order_number']; ?></strong>
            </div>
            <div class="order-row">
                <span>Tanggal</span>
                <span><?php echo date('d F Y', strtotime($order['created_at'])); ?></span>
            </div>
            <div class="order-row">
                <span>Total Pembayaran</span>
                <strong style="color: #c0392b;">Rp <?php echo number_format($order['grand_total'], 0, ',', '.'); ?></strong>
            </div>
            <div class="order-row">
                <span>Status</span>
                <span style="color: #f39c12;">Menunggu Pembayaran</span>
            </div>
        </div>
        
        <div class="order-box">
            <strong>📋 Instruksi Pembayaran</strong><br><br>
            <p>Silakan transfer ke rekening berikut:</p>
            <p>🏦 BCA: 1234567890 a.n BookStore</p>
            <p>🏦 Mandiri: 9876543210 a.n BookStore</p>
            <p>🏦 BRI: 5678901234 a.n BookStore</p>
            <hr style="margin: 10px 0;">
            <p style="font-size: 0.85rem; color: #c0392b;">⚠️ Konfirmasi pembayaran ke WA: 0812-3456-7890</p>
        </div>
        
        <a href="index.php" class="btn-home-success">Kembali ke Beranda</a>
    </div>
</body>
</html>