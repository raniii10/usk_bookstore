<?php
require_once '../config.php';

if(!isLoggedIn() || !isAdmin()) {
    header("Location: ../login.php");
    exit();
}

$total_books = $conn->query("SELECT COUNT(*) as total FROM books")->fetch_assoc()['total'];
$total_users = $conn->query("SELECT COUNT(*) as total FROM users WHERE role='user'")->fetch_assoc()['total'];
$total_orders = $conn->query("SELECT COUNT(*) as total FROM orders")->fetch_assoc()['total'];
$total_pending = $conn->query("SELECT COUNT(*) as total FROM orders WHERE status='pending'")->fetch_assoc()['total'];
$revenue = $conn->query("SELECT SUM(grand_total) as total FROM orders WHERE status='paid'")->fetch_assoc()['total'] ?? 0;

$users = $conn->query("SELECT * FROM users WHERE role='user' ORDER BY id DESC");
$orders = $conn->query("SELECT orders.*, users.username FROM orders JOIN users ON orders.user_id=users.id ORDER BY orders.id DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - BookStore</title>
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f0e8; }
        
        /* SIDEBAR */
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 260px;
            height: 100%;
            background: #FCB7C7;
            padding: 1.5rem;
        }
        .sidebar .logo {
            font-size: 1.5rem;
            font-weight: bold;
            margin-bottom: 2rem;
            text-align: center;
            color: #2c1810;
        }
        .sidebar .logo span { color: #e94560; }
        .sidebar .search {
            background: rgba(0,0,0,0.1);
            border-radius: 8px;
            padding: 0.5rem 1rem;
            margin-bottom: 1.5rem;
        }
        .sidebar .search input {
            background: none;
            border: none;
            width: 100%;
            outline: none;
            color: #2c1810;
        }
        .sidebar .search input::placeholder {
            color: #2c1810;
            opacity: 0.7;
        }
        .sidebar .user-info {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid rgba(0,0,0,0.1);
        }
        .sidebar .avatar {
            width: 45px;
            height: 45px;
            background: #e94560;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.2rem;
        }
        .sidebar nav a {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            padding: 0.7rem 1rem;
            color: #2c1810;
            text-decoration: none;
            border-radius: 8px;
            margin-bottom: 0.3rem;
            transition: 0.3s;
        }
        .sidebar nav a i {
            width: 22px;
            font-size: 1rem;
        }
        .sidebar nav a:hover, .sidebar nav a.active {
            background: #FFCEE3;
        }
        
        /* MAIN CONTENT */
        .main-content {
            margin-left: 260px;
            padding: 1.5rem;
        }
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }
        .top-bar h1 { color: #2c1810; font-size: 1.5rem; }
        .logout-btn {
            background: #e94560;
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            text-decoration: none;
        }
        .cards {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 1rem;
            margin-bottom: 2rem;
        }
        .card {
            background: white;
            border-radius: 15px;
            padding: 1rem;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .card h3 { font-size: 1.8rem; color: #e94560; margin-bottom: 0.3rem; }
        .card p { color: #666; font-size: 0.8rem; }
        .section-card {
            background: white;
            border-radius: 15px;
            padding: 1rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .section-card h2 {
            color: #2c1810;
            margin-bottom: 1rem;
            border-left: 4px solid #FCB7C7;
            padding-left: 1rem;
            font-size: 1.2rem;
        }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 0.5rem; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #FCB7C7; color: #2c1810; font-weight: 600; }
        .status-pending { color: #f39c12; font-weight: bold; }
        .status-paid { color: #28a745; font-weight: bold; }
        .status-shipped { color: #3498db; font-weight: bold; }
        select { padding: 0.3rem; border-radius: 5px; border: 1px solid #ddd; }
        .btn-add {
            background: #FCB7C7;
            color: #2c1810;
            padding: 0.3rem 0.8rem;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-bottom: 1rem;
            text-decoration: none;
            display: inline-block;
        }
        .btn-edit {
            background: #FFCEE3;
            color: #2c1810;
            padding: 0.2rem 0.6rem;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn-delete {
            background: #e94560;
            color: white;
            padding: 0.2rem 0.6rem;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        @media (max-width: 768px) {
            .sidebar { width: 200px; }
            .main-content { margin-left: 200px; }
            .cards { grid-template-columns: repeat(2, 1fr); }
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo">Book<span>Store</span></div>
        <div class="search"><input type="text" placeholder="Search here..."></div>
        <div class="user-info">
            <div class="avatar">A</div>
            <div><strong><?php echo $_SESSION['full_name']; ?></strong><br><small>Super Admin</small></div>
        </div>
        <nav>
            <a href="#" class="active" onclick="showTab('dashboard')"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            <a href="#" onclick="showTab('kategori')"><i class="fas fa-folder"></i> Kategori</a>
            <a href="#" onclick="showTab('buku')"><i class="fas fa-book"></i> Buku</a>
            <a href="#" onclick="showTab('user')"><i class="fas fa-users"></i> User</a>
            <a href="#" onclick="showTab('pesanan')"><i class="fas fa-shopping-cart"></i> Pesanan</a>
        </nav>
    </div>

    <div class="main-content">
        <div class="top-bar">
            <h1>Dashboard</h1>
            <a href="../logout.php" class="logout-btn">Logout</a>
        </div>

        <div id="dashboard" class="tab-content active">
            <div class="cards">
                <div class="card"><h3><?php echo $total_books; ?></h3><p>Total Buku</p></div>
                <div class="card"><h3><?php echo $total_users; ?></h3><p>Total User</p></div>
                <div class="card"><h3><?php echo $total_orders; ?></h3><p>Total Pesanan</p></div>
                <div class="card"><h3><?php echo $total_pending; ?></h3><p>Pending</p></div>
                <div class="card"><h3>Rp <?php echo number_format($revenue,0,',','.'); ?></h3><p>Pendapatan</p></div>
            </div>
        </div>

        <div id="kategori" class="tab-content">
            <div class="section-card">
                <h2>Kelola Kategori</h2>
                <button class="btn-add" onclick="alert('Tambah kategori')">+ Tambah</button>
                <table>
                    <thead><tr><th>ID</th><th>Nama Kategori</th><th>Aksi</th></tr></thead>
                    <tbody>
                        <tr><td>1</td><td>Fiksi</td><td><button class="btn-edit">Edit</button> <button class="btn-delete">Hapus</button></td></tr>
                        <tr><td>2</td><td>Non Fiksi</td><td><button class="btn-edit">Edit</button> <button class="btn-delete">Hapus</button></td></tr>
                        <tr><td>3</td><td>Pendidikan</td><td><button class="btn-edit">Edit</button> <button class="btn-delete">Hapus</button></td></tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div id="buku" class="tab-content">
            <div class="section-card">
                <h2>Kelola Buku</h2>
                <a href="admin_books.php" class="btn-add">+ Tambah Buku</a>
                <div style="overflow-x:auto">
                    <table>
                        <thead><tr><th>ID</th><th>Judul</th><th>Penulis</th><th>Kategori</th><th>Harga</th><th>Aksi</th></tr></thead>
                        <tbody>
                            <?php 
                            $books = $conn->query("SELECT * FROM books ORDER BY id DESC LIMIT 10");
                            while($book = $books->fetch_assoc()): 
                            ?>
                            <tr>
                                <td><?php echo $book['id']; ?></td>
                                <td><?php echo $book['title']; ?></td>
                                <td><?php echo $book['author']; ?></td>
                                <td><?php echo $book['category']; ?></td>
                                <td>Rp <?php echo number_format($book['discounted_price'],0,',','.'); ?></td>
                                <td><button class="btn-edit">Edit</button> <button class="btn-delete">Hapus</button></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div id="user" class="tab-content">
            <div class="section-card">
                <h2>List User Terdaftar</h2>
                <div style="overflow-x:auto">
                    <table>
                        <thead><tr><th>ID</th><th>Username</th><th>Email</th><th>Nama</th><th>Telepon</th></tr></thead>
                        <tbody>
                            <?php while($user = $users->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $user['id']; ?></td>
                                <td><?php echo $user['username']; ?></td>
                                <td><?php echo $user['email']; ?></td>
                                <td><?php echo $user['full_name']; ?></td>
                                <td><?php echo $user['phone']; ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div id="pesanan" class="tab-content">
            <div class="section-card">
                <h2>List Pesanan User</h2>
                <div style="overflow-x:auto">
                    <form method="POST">
                        <table>
                            <thead><tr><th>ID</th><th>No Pesanan</th><th>User</th><th>Total</th><th>Status</th><th>Aksi</th></tr></thead>
                            <tbody>
                                <?php while($order = $orders->fetch_assoc()): 
                                    $status_class = '';
                                    switch($order['status']) {
                                        case 'pending': $status_class = 'status-pending'; break;
                                        case 'paid': $status_class = 'status-paid'; break;
                                        case 'shipped': $status_class = 'status-shipped'; break;
                                    }
                                ?>
                                <tr>
                                    <td><?php echo $order['id']; ?></td>
                                    <td><?php echo $order['order_number']; ?></td>
                                    <td><?php echo $order['username']; ?></td>
                                    <td>Rp <?php echo number_format($order['grand_total'],0,',','.'); ?></td>
                                    <td class="<?php echo $status_class; ?>"><?php echo ucfirst($order['status']); ?></td>
                                    <td>
                                        <select name="status" onchange="updateStatus(<?php echo $order['id']; ?>, this.value)">
                                            <option value="pending" <?php echo $order['status']=='pending'?'selected':''; ?>>Pending</option>
                                            <option value="paid" <?php echo $order['status']=='paid'?'selected':''; ?>>Paid</option>
                                            <option value="shipped" <?php echo $order['status']=='shipped'?'selected':''; ?>>Shipped</option>
                                            <option value="completed" <?php echo $order['status']=='completed'?'selected':''; ?>>Completed</option>
                                            <option value="cancelled" <?php echo $order['status']=='cancelled'?'selected':''; ?>>Cancelled</option>
                                        </select>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        function showTab(tabId) {
            document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
            document.getElementById(tabId).classList.add('active');
            document.querySelectorAll('.sidebar nav a').forEach(a => a.classList.remove('active'));
            event.target.closest('a').classList.add('active');
        }
        function updateStatus(orderId, status) {
            fetch('update_status.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'order_id=' + orderId + '&status=' + status
            }).then(() => location.reload());
        }
    </script>
</body>
</html>