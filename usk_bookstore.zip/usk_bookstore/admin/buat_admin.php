<?php
require_once 'config.php';

$conn->query("DELETE FROM users WHERE username = 'admin'");

$password = password_hash('admin123', PASSWORD_DEFAULT);
$conn->query("INSERT INTO users (username, email, password, full_name, phone, address, role) 
              VALUES ('admin', 'admin@bookstore.com', '$password', 'Administrator', '081234567890', 'Jakarta', 'admin')");

echo "✅ Admin selesai dibuat!<br>";
echo "Username: admin<br>";
echo "Password: admin123<br>";
echo "<a href='login.php'>Klik untuk login</a>";
?>