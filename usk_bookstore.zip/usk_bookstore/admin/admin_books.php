<?php
require_once '../config.php';

if(!isLoggedIn() || !isAdmin()) {
    header("Location: ../login.php");
    exit();
}

// TAMBAH BUKU
if(isset($_POST['add_book'])) {
    $title = $_POST['title'];
    $author = $_POST['author'];
    $original_price = $_POST['original_price'];
    $discounted_price = $_POST['discounted_price'];
    $category = $_POST['category'];
    $is_bestseller = isset($_POST['is_bestseller']) ? 1 : 0;
    
    $stmt = $conn->prepare("INSERT INTO books (title, author, original_price, discounted_price, category, is_bestseller) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssddsi", $title, $author, $original_price, $discounted_price, $category, $is_bestseller);
    $stmt->execute();
    header("Location: admin_books.php");
    exit();
}

// EDIT BUKU
if(isset($_POST['edit_book'])) {
    $id = $_POST['id'];
    $title = $_POST['title'];
    $author = $_POST['author'];
    $original_price = $_POST['original_price'];
    $discounted_price = $_POST['discounted_price'];
    $category = $_POST['category'];
    $is_bestseller = isset($_POST['is_bestseller']) ? 1 : 0;
    
    $stmt = $conn->prepare("UPDATE books SET title=?, author=?, original_price=?, discounted_price=?, category=?, is_bestseller=? WHERE id=?");
    $stmt->bind_param("ssddsii", $title, $author, $original_price, $discounted_price, $category, $is_bestseller, $id);
    $stmt->execute();
    header("Location: admin_books.php");
    exit();
}

$books = $conn->query("SELECT * FROM books ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Buku - Admin</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f0e8; }
        .admin-container { max-width: 1000px; margin: 2rem auto; padding: 0 1rem; }
        .admin-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; }
        .admin-header h1 { color: #2c1810; }
        .btn-back { background: #2c1810; color: white; padding: 0.5rem 1rem; text-decoration: none; border-radius: 8px; }
        .card { background: white; border-radius: 15px; padding: 1.5rem; margin-bottom: 2rem; box-shadow: 0 5px 20px rgba(0,0,0,0.1); }
        .card h2 { color: #2c1810; margin-bottom: 1rem; border-left: 4px solid #FCB7C7; padding-left: 1rem; }
        .btn-add { background: #28a745; color: white; padding: 0.5rem 1rem; border: none; border-radius: 8px; cursor: pointer; margin-bottom: 1rem; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 0.5rem; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #FCB7C7; color: #2c1810; }
        .btn-edit { background: #FFCEE3; color: #2c1810; padding: 0.3rem 0.8rem; border: none; border-radius: 5px; cursor: pointer; }
        .btn-delete { background: #dc3545; color: white; padding: 0.3rem 0.8rem; border: none; border-radius: 5px; cursor: pointer; }
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; }
        .modal-content { background: white; max-width: 450px; margin: 3rem auto; padding: 2rem; border-radius: 15px; }
        .modal-content h3 { color: #2c1810; margin-bottom: 1rem; text-align: center; }
        .modal-content input, .modal-content select { width: 100%; padding: 0.7rem; margin: 0.5rem 0; border: 1px solid #ddd; border-radius: 8px; }
        .modal-content label { display: flex; align-items: center; gap: 0.5rem; margin: 0.5rem 0; }
        .modal-content button { width: 100%; background: #FCB7C7; color: #2c1810; padding: 0.7rem; border: none; border-radius: 8px; cursor: pointer; margin-top: 1rem; font-weight: bold; }
        .modal-content button:hover { background: #FFCEE3; }
        .close { float: right; font-size: 1.5rem; cursor: pointer; color: #999; }
        .close:hover { color: #2c1810; }
        @media (max-width: 768px) { table { font-size: 0.8rem; } }
    </style>
</head>
<body>
    <div class="admin-container">
        <div class="admin-header">
            <h1>📚 Kelola Buku</h1>
            <a href="dashboard.php" class="btn-back">Kembali ke Dashboard</a>
        </div>

        <div class="card">
            <h2>Daftar Buku</h2>
            <button class="btn-add" onclick="openAddModal()">+ Tambah Buku</button>
            <div style="overflow-x:auto">
                <table>
                    <thead>
                        <tr><th>ID</th><th>Judul</th><th>Penulis</th><th>Kategori</th><th>Harga Asli</th><th>Harga Diskon</th><th>Bestseller</th><th>Aksi</th></tr>
                    </thead>
                    <tbody>
                        <?php while($book = $books->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $book['id']; ?></td>
                            <td><?php echo $book['title']; ?></td>
                            <td><?php echo $book['author']; ?></td>
                            <td><?php echo $book['category']; ?></td>
                            <td>Rp <?php echo number_format($book['original_price'],0,',','.'); ?></td>
                            <td>Rp <?php echo number_format($book['discounted_price'],0,',','.'); ?></td>
                            <td><?php echo $book['is_bestseller'] ? '✅ Ya' : '❌ Tidak'; ?></td>
                            <td>
                                <button class="btn-edit" onclick="editBook(<?php echo htmlspecialchars(json_encode($book)); ?>)">Edit</button>
                                <button class="btn-delete" onclick="alert('⚠️ Tidak bisa menghapus buku!')">Hapus</button>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- MODAL TAMBAH BUKU -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeAddModal()">&times;</span>
            <h3>+ Tambah Buku</h3>
            <form method="POST">
                <input type="text" name="title" placeholder="Judul Buku" required>
                <input type="text" name="author" placeholder="Penulis" required>
                <input type="number" name="original_price" placeholder="Harga Asli" required>
                <input type="number" name="discounted_price" placeholder="Harga Diskon" required>
                <select name="category" required>
                    <option value="">Pilih Kategori</option>
                    <option value="Fiksi">Fiksi</option>
                    <option value="Non Fiksi">Non Fiksi</option>
                    <option value="Pendidikan">Pendidikan</option>
                </select>
                <label><input type="checkbox" name="is_bestseller"> Jadikan Bestseller</label>
                <button type="submit" name="add_book">Simpan</button>
            </form>
        </div>
    </div>

    <!-- MODAL EDIT BUKU -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeEditModal()">&times;</span>
            <h3>✏️ Edit Buku</h3>
            <form method="POST" id="editForm">
                <input type="hidden" name="id" id="edit_id">
                <input type="text" name="title" id="edit_title" placeholder="Judul Buku" required>
                <input type="text" name="author" id="edit_author" placeholder="Penulis" required>
                <input type="number" name="original_price" id="edit_original_price" placeholder="Harga Asli" required>
                <input type="number" name="discounted_price" id="edit_discounted_price" placeholder="Harga Diskon" required>
                <select name="category" id="edit_category" required>
                    <option value="Fiksi">Fiksi</option>
                    <option value="Non Fiksi">Non Fiksi</option>
                    <option value="Pendidikan">Pendidikan</option>
                </select>
                <label><input type="checkbox" name="is_bestseller" id="edit_bestseller"> Jadikan Bestseller</label>
                <button type="submit" name="edit_book">Update</button>
            </form>
        </div>
    </div>

    <script>
        function openAddModal() { document.getElementById('addModal').style.display = 'block'; }
        function closeAddModal() { document.getElementById('addModal').style.display = 'none'; }
        function closeEditModal() { document.getElementById('editModal').style.display = 'none'; }
        function editBook(book) {
            document.getElementById('edit_id').value = book.id;
            document.getElementById('edit_title').value = book.title;
            document.getElementById('edit_author').value = book.author;
            document.getElementById('edit_original_price').value = book.original_price;
            document.getElementById('edit_discounted_price').value = book.discounted_price;
            document.getElementById('edit_category').value = book.category;
            document.getElementById('edit_bestseller').checked = book.is_bestseller == 1;
            document.getElementById('editModal').style.display = 'block';
        }
        window.onclick = function(event) {
            if(event.target.classList.contains('modal')) event.target.style.display = 'none';
        }
    </script>
</body>
</html>