<?php
require_once '../config.php';

if(!isLoggedIn() || !isAdmin()) {
    header("Location: ../login.php");
    exit();
}

// Proses update status
if(isset($_POST['update_status'])) {
    $order_id = $_POST['order_id'];
    $status = $_POST['status'];
    $conn->query("UPDATE orders SET status = '$status' WHERE id = $order_id");
    header("Location: dashboard.php");
    exit();
}

// Statistik
$total_books = $conn->query("SELECT COUNT(*) as total FROM books")->fetch_assoc()['total'];
$total_users = $conn->query("SELECT COUNT(*) as total FROM users WHERE role='user'")->fetch_assoc()['total'];
$total_orders = $conn->query("SELECT COUNT(*) as total FROM orders")->fetch_assoc()['total'];
$total_pending = $conn->query("SELECT COUNT(*) as total FROM orders WHERE status='pending'")->fetch_assoc()['total'];
$revenue = $conn->query("SELECT SUM(grand_total) as total FROM orders WHERE status='paid'")->fetch_assoc()['total'] ?? 0;

// Tambahan statistik
$total_messages = $conn->query("SELECT COUNT(*) as total FROM messages WHERE is_read = 0")->fetch_assoc()['total'];
$total_bestseller = $conn->query("SELECT COUNT(*) as total FROM books WHERE is_bestseller = 1")->fetch_assoc()['total'];
$total_categories = $conn->query("SELECT COUNT(*) as total FROM categories")->fetch_assoc()['total'];

// Pesanan terbaru (5 data)
$recent_orders = $conn->query("
    SELECT orders.*, users.username 
    FROM orders 
    JOIN users ON orders.user_id = users.id 
    ORDER BY orders.id DESC 
    LIMIT 5
");

// Buku terbaru (5 data)
$recent_books = $conn->query("SELECT * FROM books ORDER BY id DESC LIMIT 5");

$users = $conn->query("SELECT * FROM users WHERE role='user' ORDER BY id DESC");
$orders = $conn->query("SELECT orders.*, users.username FROM orders JOIN users ON orders.user_id=users.id ORDER BY orders.id DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - BookStore</title>
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f0e8; color: #2c1810; }
        
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 260px;
            height: 100%;
            background: #FCB7C7;
            padding: 1.5rem;
        }
        .sidebar .logo {
            font-size: 1.5rem;
            font-weight: bold;
            margin-bottom: 2rem;
            text-align: center;
            color: #2c1810;
        }
        .sidebar .search {
            background: rgba(0,0,0,0.1);
            border-radius: 8px;
            padding: 0.5rem 1rem;
            margin-bottom: 1.5rem;
        }
        .sidebar .search input {
            background: none;
            border: none;
            width: 100%;
            outline: none;
            color: #2c1810;
        }
        .sidebar .user-info {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid rgba(0,0,0,0.1);
        }
        .sidebar .avatar {
            width: 45px;
            height: 45px;
            background: #e94560;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }
        .sidebar nav a {
            display: block;
            padding: 0.7rem 1rem;
            color: #2c1810;
            text-decoration: none;
            border-radius: 8px;
            margin-bottom: 0.3rem;
            transition: 0.3s;
        }
        .sidebar nav a:hover, .sidebar nav a.active {
            background: #FFCEE3;
        }
        
        .main-content {
            margin-left: 260px;
            padding: 1.5rem;
        }
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }
        .top-bar h1 { color: #2c1810; font-size: 1.5rem; }
        .logout-btn {
            background: #e94560;
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            text-decoration: none;
        }
        .cards {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 1rem;
            margin-bottom: 2rem;
        }
        .card {
            background: white;
            border-radius: 15px;
            padding: 1rem;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .card h3 { font-size: 1.5rem; color: #e94560; }
        .card p { font-size: 0.8rem; color: #666; margin-top: 0.3rem; }
        .stats-row {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 1rem;
            margin-bottom: 2rem;
        }
        .stats-card {
            background: white;
            border-radius: 12px;
            padding: 0.8rem;
            display: flex;
            align-items: center;
            gap: 1rem;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .stats-icon {
            width: 45px;
            height: 45px;
            background: #FCB7C7;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
        }
        .stats-info h4 { font-size: 0.8rem; color: #666; }
        .stats-info h3 { font-size: 1.3rem; color: #2c1810; }
        .recent-section {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        .recent-card {
            background: white;
            border-radius: 12px;
            padding: 1rem;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .recent-card h3 {
            font-size: 1rem;
            margin-bottom: 0.8rem;
            border-left: 3px solid #FCB7C7;
            padding-left: 0.8rem;
        }
        .recent-item {
            display: flex;
            justify-content: space-between;
            padding: 0.5rem 0;
            border-bottom: 1px solid #eee;
            font-size: 0.85rem;
        }
        .recent-item:last-child { border-bottom: none; }
        .status-badge {
            padding: 0.2rem 0.5rem;
            border-radius: 20px;
            font-size: 0.7rem;
        }
        .status-pending { background: #f39c12; color: white; }
        .status-paid { background: #28a745; color: white; }
        .status-shipped { background: #3498db; color: white; }
        .section-card {
            background: white;
            border-radius: 15px;
            padding: 1rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .section-card h2 {
            color: #2c1810;
            margin-bottom: 1rem;
            border-left: 4px solid #FCB7C7;
            padding-left: 1rem;
            font-size: 1.2rem;
        }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 0.5rem; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #FCB7C7; color: #2c1810; }
        select { padding: 0.3rem; border-radius: 5px; border: 1px solid #ddd; }
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        @media (max-width: 768px) {
            .sidebar { width: 200px; }
            .main-content { margin-left: 200px; }
            .cards { grid-template-columns: repeat(2, 1fr); }
            .stats-row { grid-template-columns: 1fr; }
            .recent-section { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo">BookStore</div>
        <div class="search"><input type="text" placeholder="Search..."></div>
        <div class="user-info">
            <div class="avatar">A</div>
            <div><strong><?php echo $_SESSION['full_name']; ?></strong><br><small>Administrator</small></div>
        </div>
        <nav>
            <a href="#" class="active" onclick="showTab('dashboard')"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            <a href="#" onclick="showTab('user')"><i class="fas fa-users"></i> User</a>
            <a href="#" onclick="showTab('pesanan')"><i class="fas fa-shopping-cart"></i> Pesanan</a>
            <a href="messages.php"><i class="fas fa-envelope"></i> Pesan</a>
            <a href="admin_books.php"><i class="fas fa-book"></i> Buku</a>
        </nav>
    </div>

    <div class="main-content">
        <div class="top-bar">
            <h1>Dashboard</h1>
            <a href="../logout.php" class="logout-btn">Logout</a>
        </div>

        <!-- DASHBOARD -->
        <div id="dashboard" class="tab-content active">
            <!-- CARD UTAMA -->
            <div class="cards">
                <div class="card"><h3><?php echo $total_books; ?></h3><p>Total Buku</p></div>
                <div class="card"><h3><?php echo $total_users; ?></h3><p>Total User</p></div>
                <div class="card"><h3><?php echo $total_orders; ?></h3><p>Total Pesanan</p></div>
                <div class="card"><h3>Rp <?php echo number_format($revenue,0,',','.'); ?></h3><p>Pendapatan</p></div>
            </div>

            <!-- STATISTIK TAMBAHAN -->
            <div class="stats-row">
                <div class="stats-card">
                    <div class="stats-icon"><i class="fas fa-envelope"></i></div>
                    <div class="stats-info">
                        <h4>Pesan Belum Dibaca</h4>
                        <h3><?php echo $total_messages; ?></h3>
                    </div>
                </div>
                <div class="stats-card">
                    <div class="stats-icon"><i class="fas fa-star"></i></div>
                    <div class="stats-info">
                        <h4>Buku Bestseller</h4>
                        <h3><?php echo $total_bestseller; ?></h3>
                    </div>
                </div>
                <div class="stats-card">
                    <div class="stats-icon"><i class="fas fa-folder"></i></div>
                    <div class="stats-info">
                        <h4>Kategori Buku</h4>
                        <h3><?php echo $total_categories; ?></h3>
                    </div>
                </div>
            </div>

            <!-- PESANAN TERBARU & BUKU TERBARU -->
            <div class="recent-section">
                <div class="recent-card">
                    <h3><i class="fas fa-clock"></i> Pesanan Terbaru</h3>
                    <?php while($order = $recent_orders->fetch_assoc()): ?>
                    <div class="recent-item">
                        <span><?php echo $order['order_number']; ?></span>
                        <span class="status-badge status-<?php echo $order['status']; ?>"><?php echo ucfirst($order['status']); ?></span>
                    </div>
                    <?php endwhile; ?>
                </div>
                <div class="recent-card">
                    <h3><i class="fas fa-book"></i> Buku Terbaru</h3>
                    <?php while($book = $recent_books->fetch_assoc()): ?>
                    <div class="recent-item">
                        <span><?php echo $book['title']; ?></span>
                        <span style="color: #c0392b;">Rp <?php echo number_format($book['discounted_price'],0,',','.'); ?></span>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </div>

        <!-- LIST USER (TIDAK BERUBAH) -->
        <div id="user" class="tab-content">
            <div class="section-card">
                <h2>List User Terdaftar</h2>
                <div style="overflow-x:auto">
                    <table>
                        <thead><tr><th>ID</th><th>Username</th><th>Email</th><th>Nama</th><th>Telepon</th><th>Alamat</th></tr></thead>
                        <tbody>
                            <?php while($user = $users->fetch_assoc()): ?>
                            <tr><td><?php echo $user['id']; ?></td><td><?php echo $user['username']; ?></td><td><?php echo $user['email']; ?></td><td><?php echo $user['full_name']; ?></td><td><?php echo $user['phone']; ?></td><td><?php echo $user['address']; ?></td></tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- LIST PESANAN (TIDAK BERUBAH) -->
        <div id="pesanan" class="tab-content">
            <div class="section-card">
                <h2>List Pesanan User</h2>
                <div style="overflow-x:auto">
                    <form method="POST">
                        <table>
                            <thead><tr><th>ID</th><th>No Pesanan</th><th>User</th><th>Total</th><th>Metode</th><th>Status</th><th>Tanggal</th><th>Aksi</th></tr></thead>
                            <tbody>
                                <?php while($order = $orders->fetch_assoc()): 
                                    $status_class = '';
                                    switch($order['status']) {
                                        case 'pending': $status_class = 'status-pending'; break;
                                        case 'paid': $status_class = 'status-paid'; break;
                                        case 'shipped': $status_class = 'status-shipped'; break;
                                        case 'completed': $status_class = 'status-paid'; break;
                                        case 'cancelled': $status_class = 'status-pending'; break;
                                    }
                                ?>
                                <tr>
                                    <td><?php echo $order['id']; ?></td>
                                    <td><?php echo $order['order_number']; ?></td>
                                    <td><?php echo $order['username']; ?></td>
                                    <td>Rp <?php echo number_format($order['grand_total'],0,',','.'); ?></td>
                                    <td><?php echo $order['payment_method']; ?></td>
                                    <td class="<?php echo $status_class; ?>"><?php echo ucfirst($order['status']); ?></td>
                                    <td><?php echo date('d/m/Y', strtotime($order['created_at'])); ?></td>
                                    <td>
                                        <select name="status" onchange="this.form.submit()">
                                            <option value="pending" <?php echo $order['status']=='pending'?'selected':''; ?>>Pending</option>
                                            <option value="paid" <?php echo $order['status']=='paid'?'selected':''; ?>>Paid</option>
                                            <option value="shipped" <?php echo $order['status']=='shipped'?'selected':''; ?>>Shipped</option>
                                            <option value="completed" <?php echo $order['status']=='completed'?'selected':''; ?>>Completed</option>
                                            <option value="cancelled" <?php echo $order['status']=='cancelled'?'selected':''; ?>>Cancelled</option>
                                        </select>
                                        <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                        <input type="hidden" name="update_status" value="1">
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        function showTab(tabId) {
            document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
            document.getElementById(tabId).classList.add('active');
        }
    </script>
</body>
</html>