<?php
require_once 'config.php';

// Coba update buku dengan ID 1
$id = 1;
$new_price = 50000;

$stmt = $conn->prepare("UPDATE books SET discounted_price = ? WHERE id = ?");
$stmt->bind_param("di", $new_price, $id);

if($stmt->execute()) {
    echo "✅ Update berhasil! Harga buku ID $id menjadi Rp " . number_format($new_price,0,',','.');
} else {
    echo "❌ Gagal: " . $conn->error;
}
?>