<?php
require_once '../config.php';

if(!isLoggedIn() || !isAdmin()) {
    header("Location: ../login.php");
    exit();
}

// Tandai pesan sudah dibaca
if(isset($_GET['read'])) {
    $id = $_GET['read'];
    $conn->query("UPDATE messages SET is_read = 1 WHERE id = $id");
    header("Location: messages.php");
    exit();
}

// Hapus pesan
if(isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM messages WHERE id = $id");
    header("Location: messages.php");
    exit();
}

$messages = $conn->query("SELECT * FROM messages ORDER BY is_read ASC, id DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesan Masuk - Admin</title>
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f5f0e8;
            color: #2c1810;
        }
        .admin-container {
            max-width: 1100px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        .admin-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            gap: 1rem;
        }
        .admin-header h1 {
            font-size: 1.5rem;
            color: #2c1810;
        }
        .btn-back {
            background: #2c1810;
            color: white;
            padding: 0.5rem 1rem;
            text-decoration: none;
            border-radius: 6px;
            font-size: 0.85rem;
        }
        .stats {
            display: flex;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        .stat-box {
            background: white;
            padding: 0.8rem 1.2rem;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }
        .stat-box span {
            font-size: 0.8rem;
            color: #666;
        }
        .stat-box strong {
            font-size: 1.3rem;
            color: #e94560;
            margin-left: 0.5rem;
        }
        .message-list {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }
        .message-item {
            border-bottom: 1px solid #eee;
            transition: 0.2s;
        }
        .message-item:hover {
            background: #fafafa;
        }
        .message-item.unread {
            background: #fff9f0;
            border-left: 3px solid #e94560;
        }
        .message-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem;
            cursor: pointer;
        }
        .message-sender {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            flex-wrap: wrap;
        }
        .sender-name {
            font-weight: 600;
            color: #2c1810;
        }
        .sender-email {
            font-size: 0.8rem;
            color: #999;
        }
        .message-date {
            font-size: 0.75rem;
            color: #999;
        }
        .message-badge {
            background: #e94560;
            color: white;
            font-size: 0.65rem;
            padding: 0.2rem 0.5rem;
            border-radius: 20px;
        }
        .message-body {
            padding: 0 1rem 1rem 1rem;
            display: none;
        }
        .message-body.show {
            display: block;
        }
        .message-subject {
            font-weight: 600;
            color: #2c1810;
            margin-bottom: 0.5rem;
        }
        .message-content {
            color: #444;
            line-height: 1.5;
            font-size: 0.9rem;
            margin-bottom: 1rem;
            background: #f9f9f9;
            padding: 0.8rem;
            border-radius: 8px;
        }
        .message-actions {
            display: flex;
            gap: 0.8rem;
        }
        .btn-read, .btn-delete {
            padding: 0.3rem 0.8rem;
            border-radius: 5px;
            text-decoration: none;
            font-size: 0.75rem;
        }
        .btn-read {
            background: #28a745;
            color: white;
        }
        .btn-delete {
            background: #dc3545;
            color: white;
        }
        .no-messages {
            text-align: center;
            padding: 3rem;
            background: white;
            border-radius: 12px;
            color: #999;
        }
        .toggle-icon {
            font-size: 0.8rem;
            color: #999;
            transition: 0.2s;
        }
        .message-header:hover .toggle-icon {
            color: #2c1810;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <div class="admin-header">
            <h1><i class="fas fa-envelope"></i> Pesan Masuk</h1>
            <a href="dashboard.php" class="btn-back"><i class="fas fa-arrow-left"></i> Kembali</a>
        </div>

        <?php 
        $total_unread = 0;
        $messages->data_seek(0);
        while($msg = $messages->fetch_assoc()) {
            if(!$msg['is_read']) $total_unread++;
        }
        ?>

        <div class="stats">
            <div class="stat-box">
                <span>Total Pesan</span>
                <strong><?php echo $messages->num_rows; ?></strong>
            </div>
            <div class="stat-box">
                <span>Belum Dibaca</span>
                <strong><?php echo $total_unread; ?></strong>
            </div>
        </div>

        <?php if($messages->num_rows > 0): ?>
            <div class="message-list">
                <?php $messages->data_seek(0); ?>
                <?php while($msg = $messages->fetch_assoc()): ?>
                <div class="message-item <?php echo $msg['is_read'] ? '' : 'unread'; ?>">
                    <div class="message-header" onclick="toggleMessage(this)">
                        <div class="message-sender">
                            <span class="sender-name"><?php echo htmlspecialchars($msg['name']); ?></span>
                            <span class="sender-email">&lt;<?php echo htmlspecialchars($msg['email']); ?>&gt;</span>
                            <?php if(!$msg['is_read']): ?>
                                <span class="message-badge">Baru</span>
                            <?php endif; ?>
                        </div>
                        <div style="display: flex; align-items: center; gap: 1rem;">
                            <span class="message-date"><?php echo date('d M Y H:i', strtotime($msg['created_at'])); ?></span>
                            <i class="fas fa-chevron-down toggle-icon"></i>
                        </div>
                    </div>
                    <div class="message-body">
                        <?php if($msg['subject']): ?>
                            <div class="message-subject">📌 <?php echo htmlspecialchars($msg['subject']); ?></div>
                        <?php endif; ?>
                        <div class="message-content">
                            <?php echo nl2br(htmlspecialchars($msg['message'])); ?>
                        </div>
                        <div class="message-actions">
                            <?php if(!$msg['is_read']): ?>
                                <a href="?read=<?php echo $msg['id']; ?>" class="btn-read"><i class="fas fa-check"></i> Tandai Dibaca</a>
                            <?php endif; ?>
                            <a href="?delete=<?php echo $msg['id']; ?>" class="btn-delete" onclick="return confirm('Hapus pesan ini?')"><i class="fas fa-trash"></i> Hapus</a>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="no-messages">
                <i class="fas fa-inbox" style="font-size: 3rem; opacity: 0.3; margin-bottom: 1rem; display: block;"></i>
                Belum ada pesan masuk
            </div>
        <?php endif; ?>
    </div>

    <script>
        function toggleMessage(header) {
            const body = header.nextElementSibling;
            const icon = header.querySelector('.toggle-icon');
            body.classList.toggle('show');
            if(body.classList.contains('show')) {
                icon.classList.remove('fa-chevron-down');
                icon.classList.add('fa-chevron-up');
            } else {
                icon.classList.remove('fa-chevron-up');
                icon.classList.add('fa-chevron-down');
            }
        }
    </script>
</body>
</html>