<?php
require_once '../config.php';

if(!isLoggedIn() || !isAdmin()) {
    header("Location: ../login.php");
    exit();
}

// TAMBAH KATEGORI
if(isset($_POST['add_kategori'])) {
    $name = $_POST['nama_kategori'];
    if(!empty($name)) {
        $conn->query("INSERT INTO categories (name) VALUES ('$name')");
    }
    header("Location: kategori.php");
    exit();
}

// EDIT KATEGORI
if(isset($_POST['edit_kategori'])) {
    $id = $_POST['kategori_id'];
    $name = $_POST['nama_kategori'];
    $conn->query("UPDATE categories SET name = '$name' WHERE id = $id");
    header("Location: kategori.php");
    exit();
}

// HAPUS KATEGORI
if(isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM categories WHERE id = $id");
    header("Location: kategori.php");
    exit();
}

$categories = $conn->query("SELECT * FROM categories ORDER BY id");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Kategori - Admin</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f0e8;
            color: #2c1810;
        }
        .admin-container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        .admin-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }
        .admin-header h1 {
            color: #2c1810;
            font-size: 1.5rem;
        }
        .btn-back {
            background: #2c1810;
            color: white;
            padding: 0.5rem 1rem;
            text-decoration: none;
            border-radius: 8px;
        }
        .card {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        .card h2 {
            color: #2c1810;
            margin-bottom: 1rem;
            border-left: 4px solid #FCB7C7;
            padding-left: 1rem;
            font-size: 1.2rem;
        }
        .btn-add {
            background: #28a745;
            color: white;
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            margin-bottom: 1rem;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 0.5rem;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background: #FCB7C7;
            color: #2c1810;
        }
        .btn-edit {
            background: #FFCEE3;
            color: #2c1810;
            padding: 0.3rem 0.8rem;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-right: 0.3rem;
        }
        .btn-delete {
            background: #dc3545;
            color: white;
            padding: 0.3rem 0.8rem;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
        }
        .modal-content {
            background: white;
            max-width: 400px;
            margin: 3rem auto;
            padding: 1.5rem;
            border-radius: 12px;
        }
        .modal-content h3 {
            color: #2c1810;
            margin-bottom: 1rem;
            text-align: center;
        }
        .modal-content input {
            width: 100%;
            padding: 0.5rem;
            margin: 0.5rem 0;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .modal-content button {
            background: #FCB7C7;
            color: #2c1810;
            padding: 0.5rem;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
            margin-top: 0.5rem;
            font-weight: bold;
        }
        .modal-content button:hover {
            background: #FFCEE3;
        }
        .close {
            float: right;
            font-size: 1.2rem;
            cursor: pointer;
            color: #999;
        }
        .close:hover {
            color: #2c1810;
        }
        @media (max-width: 768px) {
            table {
                font-size: 0.8rem;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <div class="admin-header">
            <h1>📁 Kelola Kategori</h1>
            <a href="dashboard.php" class="btn-back">Kembali ke Dashboard</a>
        </div>

        <div class="card">
            <h2>Daftar Kategori</h2>
            <button class="btn-add" onclick="openAddModal()">+ Tambah Kategori</button>
            <div style="overflow-x:auto">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nama Kategori</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($kat = $categories->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $kat['id']; ?></td>
                            <td><?php echo $kat['name']; ?></td>
                            <td>
                                <button class="btn-edit" onclick="editKategori(<?php echo $kat['id']; ?>, '<?php echo $kat['name']; ?>')">Edit</button>
                                <a href="?delete=<?php echo $kat['id']; ?>" class="btn-delete" onclick="return confirm('Yakin hapus kategori ini?')">Hapus</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- MODAL TAMBAH KATEGORI -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeAddModal()">&times;</span>
            <h3>Tambah Kategori</h3>
            <form method="POST">
                <input type="text" name="nama_kategori" placeholder="Nama Kategori" required>
                <button type="submit" name="add_kategori">Simpan</button>
            </form>
        </div>
    </div>

    <!-- MODAL EDIT KATEGORI -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeEditModal()">&times;</span>
            <h3>Edit Kategori</h3>
            <form method="POST">
                <input type="hidden" name="kategori_id" id="edit_id">
                <input type="text" name="nama_kategori" id="edit_nama" placeholder="Nama Kategori" required>
                <button type="submit" name="edit_kategori">Update</button>
            </form>
        </div>
    </div>

    <script>
        function openAddModal() {
            document.getElementById('addModal').style.display = 'block';
        }
        function closeAddModal() {
            document.getElementById('addModal').style.display = 'none';
        }
        function closeEditModal() {
            document.getElementById('editModal').style.display = 'none';
        }
        function editKategori(id, nama) {
            document.getElementById('edit_id').value = id;
            document.getElementById('edit_nama').value = nama;
            document.getElementById('editModal').style.display = 'block';
        }
        window.onclick = function(event) {
            if(event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }
    </script>
</body>
</html> 