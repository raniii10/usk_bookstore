<?php
require_once 'config.php';
requireLogin();

$order_id = isset($_GET['order_id']) ? $_GET['order_id'] : 0;

$order_query = $conn->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
$order_query->bind_param("ii", $order_id, $_SESSION['user_id']);
$order_query->execute();
$order = $order_query->get_result()->fetch_assoc();

if (!$order) {
    header("Location: index.php");
    exit();
}

$details_query = $conn->prepare("SELECT * FROM order_details WHERE order_id = ?");
$details_query->bind_param("i", $order_id);
$details_query->execute();
$details = $details_query->get_result();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transfer Berhasil - BookStore</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .success-container {
            max-width: 800px;
            margin: 3rem auto;
            background: white;
            border-radius: 15px;
            padding: 2rem;
            text-align: center;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        .success-icon {
            font-size: 4rem;
            margin-bottom: 1rem;
        }
        .success-container h1 {
            color: #28a745;
            margin-bottom: 0.5rem;
        }
        .success-container p {
            color: #666;
            margin-bottom: 1.5rem;
        }
        .order-box {
            background: #f5f0e8;
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 1.5rem;
            text-align: left;
        }
        .order-row {
            display: flex;
            justify-content: space-between;
            padding: 0.5rem 0;
            border-bottom: 1px solid #ddd;
        }
        .order-row:last-child {
            border-bottom: none;
        }
        .bank-box {
            background: #e8f4fd;
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 1.5rem;
            text-align: left;
        }
        .btn-home {
            display: inline-block;
            background: #FCB7C7;
            color: #2c1810;
            padding: 0.8rem 2rem;
            text-decoration: none;
            border-radius: 25px;
        }
        .btn-home:hover {
            background: #FFCEE3;
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <h1 class="logo">BookStore</h1>
            <a href="index.php" style="color:#2c1810; text-decoration:none;">← Kembali ke Toko</a>
        </div>
    </header>

    <div class="success-container">
        <div class="success-icon">✅</div>
        <h1>Transfer Berhasil!</h1>
        <p>Pembayaran Anda telah kami terima</p>
        
        <div class="order-box">
            <div class="order-row">
                <span>Nomor Pesanan</span>
                <strong><?php echo $order['order_number']; ?></strong>
            </div>
            <div class="order-row">
                <span>Jumlah Transfer</span>
                <strong style="color: #c0392b;">Rp <?php echo number_format($order['grand_total'], 0, ',', '.'); ?></strong>
            </div>
            <div class="order-row">
                <span>Status</span>
                <span style="color: #28a745;">Pembayaran Dikonfirmasi</span>
            </div>
        </div>
        
        <div class="bank-box">
            <strong>📦 Pesanan Anda sedang diproses</strong><br>
            Pesanan akan segera kami proses dan dikirim dalam 1x24 jam.<br><br>
            <strong>💡 Simpan nomor pesanan ini sebagai bukti.</strong>
        </div>
        
        <a href="index.php" class="btn-home">Kembali ke Beranda</a>
    </div>
</body>
</html>