// Update cart count
function updateCartCount() {
    fetch('cart_count.php')
        .then(res => res.json())
        .then(data => {
            let cartCount = document.getElementById('cartCount');
            if(cartCount) cartCount.innerText = data.count || 0;
        });
}

// ========== SEARCH FUNCTION ==========
function searchBooks() {
    let keyword = document.getElementById('searchInput').value.toLowerCase();
    let allBooks = document.querySelectorAll('.book-card');
    
    if(keyword === '') {
        allBooks.forEach(book => book.style.display = 'block');
        return;
    }
    
    allBooks.forEach(book => {
        let title = book.getAttribute('data-title');
        if(title && title.indexOf(keyword) !== -1) {
            book.style.display = 'block';
        } else {
            book.style.display = 'none';
        }
    });
}

// ========== SETUP SEARCH ==========
document.addEventListener('DOMContentLoaded', function() {
    updateCartCount();
    
    let searchBtn = document.getElementById('searchBtn');
    let searchInput = document.getElementById('searchInput');
    
    if(searchBtn) {
        searchBtn.onclick = function(e) {
            e.preventDefault();
            searchBooks();
        };
    }
    
    if(searchInput) {
        searchInput.onkeyup = function() {
            if(this.value === '') {
                document.querySelectorAll('.book-card').forEach(book => book.style.display = 'block');
            }
        };
        searchInput.onkeypress = function(e) {
            if(e.key === 'Enter') {
                searchBooks();
            }
        };
    }
    
    // ========== ADD TO CART ==========
    document.querySelectorAll('.add-to-cart').forEach(btn => {
        btn.onclick = function() {
            fetch('add_to_cart.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'book_id=' + this.dataset.id
            }).then(res => res.json()).then(data => {
                if(data.success) {
                    updateCartCount();
                    alert('Buku ditambahkan ke keranjang');
                } else {
                    alert('Silakan login dulu');
                    window.location.href = 'login.php';
                }
            });
        }
    });
    
    // ========== CHECKOUT ==========
    document.querySelectorAll('.checkout-btn').forEach(btn => {
        btn.onclick = function() {
            fetch('add_to_cart.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'book_id=' + this.dataset.id
            }).then(() => {
                window.location.href = 'cart.php';
            });
        }
    });
});