<?php
require_once 'config.php';
requireLogin();

$user_id = $_SESSION['user_id'];

// Ambil data user
$user_query = $conn->prepare("SELECT * FROM users WHERE id = ?");
$user_query->bind_param("i", $user_id);
$user_query->execute();
$user = $user_query->get_result()->fetch_assoc();

// Ambil semua item di cart
$cart_query = $conn->prepare("
    SELECT cart.id as cart_id, cart.quantity, books.* 
    FROM cart 
    JOIN books ON cart.book_id = books.id 
    WHERE cart.user_id = ?
");
$cart_query->bind_param("i", $user_id);
$cart_query->execute();
$cart_items = $cart_query->get_result();

$total = 0;
$items = [];
while($item = $cart_items->fetch_assoc()) {
    $subtotal = $item['discounted_price'] * $item['quantity'];
    $total += $subtotal;
    $items[] = $item;
}

if (empty($items)) {
    header("Location: index.php");
    exit();
}

$shipping_cost = 15000;
$grand_total = $total + $shipping_cost;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = $_POST['full_name'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $payment_method = $_POST['payment_method'];
    
    $order_number = 'INV-' . date('Ymd') . '-' . rand(1000, 9999);
    
    $insert_order = $conn->prepare("
        INSERT INTO orders (order_number, user_id, total_amount, shipping_cost, grand_total, shipping_address, phone, payment_method, status, created_at) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', NOW())
    ");
    $insert_order->bind_param("siiddsss", $order_number, $user_id, $total, $shipping_cost, $grand_total, $address, $phone, $payment_method);
    
    if ($insert_order->execute()) {
        $order_id = $conn->insert_id;
        
        foreach ($items as $item) {
            $subtotal = $item['discounted_price'] * $item['quantity'];
            $insert_detail = $conn->prepare("
                INSERT INTO order_details (order_id, book_id, book_title, book_author, price, quantity, subtotal) 
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $insert_detail->bind_param("iissdid", $order_id, $item['id'], $item['title'], $item['author'], $item['discounted_price'], $item['quantity'], $subtotal);
            $insert_detail->execute();
        }
        
        $clear_cart = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
        $clear_cart->bind_param("i", $user_id);
        $clear_cart->execute();
        
        header("Location: order_success.php?order_id=" . $order_id);
        exit();
    } else {
        $error = "Gagal memproses pesanan. Silakan coba lagi.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - BookStore</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="header-container">
            <a href="cart.php" class="back-link">← Kembali ke Keranjang</a>
            <a href="index.php" class="logo">BookStore</a>
            <div></div>
        </div>
    </header>

    <div class="checkout-container">
        <div class="bill-section">
            <h2>Ringkasan Pesanan</h2>
            
            <div class="bill-items">
                <?php foreach($items as $item): ?>
                <div class="bill-item">
                    <div class="bill-item-info">
                        <h4><?php echo htmlspecialchars($item['title']); ?></h4>
                        <p><?php echo htmlspecialchars($item['author']); ?> | <?php echo $item['quantity']; ?> x Rp <?php echo number_format($item['discounted_price'], 0, ',', '.'); ?></p>
                    </div>
                    <div class="bill-item-price">
                        Rp <?php echo number_format($item['discounted_price'] * $item['quantity'], 0, ',', '.'); ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <div class="bill-total">
                <div class="bill-row">
                    <span>Subtotal</span>
                    <span>Rp <?php echo number_format($total, 0, ',', '.'); ?></span>
                </div>
                <div class="bill-row">
                    <span>Biaya Pengiriman</span>
                    <span>Rp <?php echo number_format($shipping_cost, 0, ',', '.'); ?></span>
                </div>
                <div class="bill-row total">
                    <span>Total Tagihan</span>
                    <span>Rp <?php echo number_format($grand_total, 0, ',', '.'); ?></span>
                </div>
            </div>
        </div>

        <div class="form-section">
            <h2>Informasi Pengiriman & Pembayaran</h2>
            
            <?php if(isset($error)): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <form method="POST" id="checkoutForm">
                <div class="form-group">
                    <label>Nama Lengkap *</label>
                    <input type="text" name="full_name" required value="<?php echo htmlspecialchars($user['full_name'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label>No. Telepon *</label>
                    <input type="text" name="phone" required value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label>Alamat Lengkap *</label>
                    <textarea name="address" required placeholder="Jalan, Kota, Kode Pos"><?php echo htmlspecialchars($user['address'] ?? ''); ?></textarea>
                </div>
                
                <div class="form-group">
                    <label>Metode Pembayaran *</label>
                    <div class="payment-methods">
                        <label class="payment-option" id="opt_transfer">
                            <input type="radio" name="payment_method" value="Bank Transfer" required> 
                            <span>🏦 Bank Transfer</span>
                        </label>
                        <label class="payment-option" id="opt_qris">
                            <input type="radio" name="payment_method" value="QRIS"> 
                            <span>📱 QRIS</span>
                        </label>
                        <label class="payment-option" id="opt_cod">
                            <input type="radio" name="payment_method" value="COD"> 
                            <span>🚚 COD (Bayar di Tempat)</span>
                        </label>
                    </div>
                </div>
                
                <button type="submit" class="btn-checkout">Konfirmasi & Bayar</button>
            </form>
        </div>
    </div>

    <script>
        document.querySelectorAll('.payment-option').forEach(option => {
            option.addEventListener('click', function() {
                document.querySelectorAll('.payment-option').forEach(opt => opt.classList.remove('selected'));
                this.classList.add('selected');
                this.querySelector('input').checked = true;
            });
            
            if(option.querySelector('input').checked) {
                option.classList.add('selected');
            }
        });
    </script>
</body>
</html>