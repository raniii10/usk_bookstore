<?php
require_once 'config.php';
requireLogin();

$user_id = $_SESSION['user_id'];
$message = '';

// Ambil data user
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Update profil
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = $_POST['full_name'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    
    $update = $conn->prepare("UPDATE users SET full_name = ?, phone = ?, address = ? WHERE id = ?");
    $update->bind_param("sssi", $full_name, $phone, $address, $user_id);
    
    if ($update->execute()) {
        $_SESSION['full_name'] = $full_name;
        $message = "Profil berhasil diupdate!";
        // Refresh data
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
    } else {
        $message = "Gagal update profil!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Profil Saya - BookStore</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .profile-container {
            max-width: 600px;
            margin: 2rem auto;
            background: white;
            padding: 2rem;
            border-radius: 15px;
        }
        .message {
            padding: 0.7rem;
            border-radius: 8px;
            margin-bottom: 1rem;
        }
        .success {
            background: #d4edda;
            color: #155724;
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <h1 class="logo">📚 BookStore</h1>
            <a href="index.php" style="color:white;">← Kembali ke Toko</a>
            <a href="logout.php" style="color:white;">Logout</a>
        </div>
    </header>

    <div class="profile-container">
        <h2>Profil Saya</h2>
        
        <?php if($message): ?>
            <div class="message success"><?php echo $message; ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label>Username</label>
                <input type="text" value="<?php echo $user['username']; ?>" disabled>
            </div>
            
            <div class="form-group">
                <label>Email</label>
                <input type="email" value="<?php echo $user['email']; ?>" disabled>
            </div>
            
            <div class="form-group">
                <label>Nama Lengkap</label>
                <input type="text" name="full_name" value="<?php echo $user['full_name']; ?>">
            </div>
            
            <div class="form-group">
                <label>No. Telepon</label>
                <input type="text" name="phone" value="<?php echo $user['phone']; ?>">
            </div>
            
            <div class="form-group">
                <label>Alamat</label>
                <textarea name="address"><?php echo $user['address']; ?></textarea>
            </div>
            
            <button type="submit" class="btn-register">Simpan Perubahan</button>
        </form>
    </div>
</body>
</html>