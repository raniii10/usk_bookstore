<?php
require_once 'config.php';
requireLogin();

$user_id = $_SESSION['user_id'];

// Update quantity
if(isset($_POST['update_cart'])) {
    foreach($_POST['quantity'] as $cart_id => $qty) {
        $qty = max(1, (int)$qty);
        $update = $conn->prepare("UPDATE cart SET quantity = ? WHERE id = ? AND user_id = ?");
        $update->bind_param("iii", $qty, $cart_id, $user_id);
        $update->execute();
    }
    header("Location: cart.php");
    exit();
}

// Remove item
if(isset($_GET['remove'])) {
    $cart_id = $_GET['remove'];
    $delete = $conn->prepare("DELETE FROM cart WHERE id = ? AND user_id = ?");
    $delete->bind_param("ii", $cart_id, $user_id);
    $delete->execute();
    header("Location: cart.php");
    exit();
}

// Get cart items
$cart_query = $conn->prepare("
    SELECT cart.id as cart_id, cart.quantity, books.* 
    FROM cart 
    JOIN books ON cart.book_id = books.id 
    WHERE cart.user_id = ?
");
$cart_query->bind_param("i", $user_id);
$cart_query->execute();
$cart_items = $cart_query->get_result();

$subtotal = 0;
$items = [];
while($item = $cart_items->fetch_assoc()) {
    $subtotal += $item['discounted_price'] * $item['quantity'];
    $items[] = $item;
}

$delivery_cost = 20000;
$discount = 0;
$total = $subtotal + $delivery_cost;

// Apply promo discount
$promo_code = '';
$promo_message = '';
$promo_applied = false;

if(isset($_POST['apply_promo'])) {
    $promo_code = trim($_POST['promo_code']);
    
    $promos = [
        'DISKON10' => 0.10,
        'DISKON20' => 0.20,
        'DISKON50' => 0.50,
        'GRATISONGKIR' => 'free_shipping',
        'WELCOME10' => 0.10,
        'BOOKLOVER' => 0.15,
        'FLASHSALE' => 0.25
    ];
    
    if(isset($promos[$promo_code])) {
        if($promos[$promo_code] === 'free_shipping') {
            $delivery_cost = 0;
            $promo_message = '✅ Promo berhasil! Ongkos kirim GRATIS.';
            $promo_applied = true;
        } else {
            $discount = $subtotal * $promos[$promo_code];
            $promo_message = '✅ Promo berhasil! Diskon ' . ($promos[$promo_code] * 100) . '% diterapkan.';
            $promo_applied = true;
        }
        $total = $subtotal - $discount + $delivery_cost;
    } else {
        $promo_message = '❌ Kode promo tidak valid!';
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart - BookStore</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .cart-container {
            max-width: 1000px;
            margin: 2rem auto;
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .cart-container h1 {
            font-size: 1.8rem;
            color: #2c1810;
            margin-bottom: 1.5rem;
        }
        .cart-table {
            width: 100%;
            border-collapse: collapse;
        }
        .cart-table th {
            text-align: left;
            padding: 1rem 0.5rem;
            border-bottom: 2px solid #eee;
            color: #666;
        }
        .cart-table td {
            padding: 1rem 0.5rem;
            border-bottom: 1px solid #eee;
            vertical-align: middle;
        }
        .product-name {
            font-weight: 600;
            color: #2c1810;
        }
        .product-author {
            font-size: 0.8rem;
            color: #999;
        }
        .qty-input {
            width: 60px;
            padding: 0.4rem;
            border: 1px solid #ddd;
            border-radius: 5px;
            text-align: center;
        }
        .remove-link {
            color: #c0392b;
            text-decoration: none;
            font-size: 0.8rem;
        }
        .cart-summary {
            display: flex;
            justify-content: space-between;
            margin: 1.5rem 0;
            padding: 1rem 0;
            border-top: 1px solid #eee;
            border-bottom: 1px solid #eee;
        }
        .discount-area {
            line-height: 1.8;
        }
        .total-area {
            text-align: right;
            line-height: 1.8;
            font-weight: bold;
        }
        .promo-section {
            margin: 1.5rem 0;
            padding: 1rem;
            background: #f9f9f9;
            border-radius: 10px;
        }
        .promo-section p {
            margin-bottom: 0.5rem;
            color: #333;
        }
        .promo-input {
            display: flex;
            gap: 0.5rem;
        }
        .promo-input input {
            flex: 1;
            padding: 0.7rem;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .btn-apply {
            background: #FCB7C7;
            color: #2c1810;
            border: none;
            padding: 0.7rem 1.5rem;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
        }
        .btn-apply:hover {
            background: #FFCEE3;
        }
        .promo-message {
            margin-top: 0.5rem;
            font-size: 0.8rem;
        }
        .promo-message.success {
            color: #28a745;
        }
        .promo-message.error {
            color: #c0392b;
        }
        .promo-list {
            margin-top: 0.5rem;
            font-size: 0.7rem;
            color: #999;
        }
        .cart-buttons {
            display: flex;
            justify-content: center;
            gap: 1rem;
            margin-top: 1.5rem;
        }
        .btn-update, .btn-checkout-cart {
            flex: 1;
            padding: 0.7rem;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            text-align: center;
        }
        .btn-update {
            background: #666;
            color: white;
        }
        .btn-checkout-cart {
            background: #FCB7C7;
            color: #2c1810;
        }
        .btn-checkout-cart:hover {
            background: #FFCEE3;
        }
        .btn-continue {
            display: block;
            width: 200px;
            margin: 1rem auto 0;
            padding: 0.7rem;
            background: #ddd;
            color: #2c1810;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
            font-weight: 600;
        }
        .btn-continue:hover {
            background: #ccc;
        }
        .empty-cart {
            text-align: center;
            padding: 3rem;
        }
        .empty-cart p {
            color: #999;
            margin-bottom: 1rem;
        }
        .btn-shop {
            background: #FCB7C7;
            color: #2c1810;
            padding: 0.7rem 1.5rem;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
        }
        @media (max-width: 768px) {
            .cart-container {
                padding: 1rem;
            }
            .cart-summary {
                flex-direction: column;
                gap: 1rem;
            }
            .total-area {
                text-align: left;
            }
            .cart-buttons {
                flex-direction: column;
            }
            .promo-input {
                flex-direction: column;
            }
            .btn-continue {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <h1 class="logo">BookStore</h1>
            <div class="header-right">
                <?php if(isLoggedIn()): ?>
                    <div class="user-menu">
                        <span class="user-name"><?php echo htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username']); ?></span>
                        <div class="dropdown-user">
                            <a href="logout.php">Logout</a>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="login.php" class="login-btn">Login</a>
                    <a href="register.php" class="register-btn">Daftar</a>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <div class="cart-container">
        <h1>My Shopping Cart</h1>
        
        <?php if(!empty($items)): ?>
        <form method="POST">
            <table class="cart-table">
                <thead>
                    <tr><th>Product</th><th>Quantity</th><th>Price</th><th></th></tr>
                </thead>
                <tbody>
                    <?php foreach($items as $item): ?>
                    <tr>
                        <td>
                            <div class="product-name"><?php echo htmlspecialchars($item['title']); ?></div>
                            <div class="product-author"><?php echo htmlspecialchars($item['author']); ?></div>
                        </div>
                        </td>
                        <td>
                            <input type="number" name="quantity[<?php echo $item['cart_id']; ?>]" 
                                   value="<?php echo $item['quantity']; ?>" 
                                   min="1" class="qty-input">
                        </div>
                        </td>
                        <td>Rp <?php echo number_format($item['discounted_price'], 0, ',', '.'); ?></td>
                        <td><a href="?remove=<?php echo $item['cart_id']; ?>" class="remove-link">Remove</a></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <div class="cart-summary">
                <div class="discount-area">
                    <strong>Discount</strong><br>
                    Discount: Rp <?php echo number_format($discount, 0, ',', '.'); ?><br>
                    Delivery: Rp <?php echo number_format($delivery_cost, 0, ',', '.'); ?>
                </div>
                <div class="total-area">
                    Subtotal: Rp <?php echo number_format($subtotal, 0, ',', '.'); ?><br>
                    Total: Rp <?php echo number_format($total, 0, ',', '.'); ?>
                </div>
            </div>
            
            <div class="promo-section">
                <p>🎁 Promo Code</p>
                <div class="promo-input">
                    <input type="text" name="promo_code" placeholder="Enter promo code" value="<?php echo htmlspecialchars($promo_code); ?>">
                    <button type="submit" name="apply_promo" class="btn-apply">Apply Discount</button>
                </div>
                <?php if($promo_message): ?>
                    <div class="promo-message <?php echo $promo_applied ? 'success' : 'error'; ?>">
                        <?php echo $promo_message; ?>
                    </div>
                <?php endif; ?>
                <div class="promo-list">
                    💡 Promo tersedia: <strong>DISKON10</strong> (10%), <strong>DISKON20</strong> (20%), <strong>DISKON50</strong> (50%), <strong>GRATISONGKIR</strong> (Free Shipping)
                </div>
            </div>
            
            <div class="cart-buttons">
                <button type="submit" name="update_cart" class="btn-update">Update Cart</button>
                <button type="button" class="btn-checkout-cart" onclick="window.location.href='payment.php'">Proceed to Checkout</button>
            </div>
            
            <a href="index.php" class="btn-continue">Continue Shopping</a>
        </form>
        
        <?php else: ?>
        <div class="empty-cart">
            <p>Your cart is empty</p>
            <a href="index.php" class="btn-shop">Continue Shopping</a>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>