<?php
require_once 'config.php';
requireLogin();

$order_id = isset($_GET['order_id']) ? $_GET['order_id'] : 0;

$order_query = $conn->prepare("
    SELECT * FROM orders WHERE id = ? AND user_id = ?
");
$order_query->bind_param("ii", $order_id, $_SESSION['user_id']);
$order_query->execute();
$order = $order_query->get_result()->fetch_assoc();

if (!$order) {
    header("Location: index.php");
    exit();
}

$details_query = $conn->prepare("SELECT * FROM order_details WHERE order_id = ?");
$details_query->bind_param("i", $order_id);
$details_query->execute();
$details = $details_query->get_result();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice - BookStore</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="header-container">
            <h1 class="logo">BookStore</h1>
            <div class="header-right">
                <a href="index.php" style="color:white; text-decoration:none;">← Continue Shopping</a>
                <?php if(isLoggedIn()): ?>
                    <div class="user-menu">
                        <span class="user-name"><?php echo htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username']); ?></span>
                        <div class="dropdown-user">
                            <a href="profile.php">Profil Saya</a>
                            <a href="logout.php">Logout</a>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <div class="invoice-container">
        <div class="invoice-card">
            <div class="invoice-header">
                <div class="invoice-status success">✓ PAYMENT SUCCESS</div>
                <div class="invoice-date"><?php echo date('d F Y, H:i'); ?></div>
            </div>
            
            <div class="invoice-body">
                <div class="invoice-title">
                    <h1>INVOICE</h1>
                    <p>#<?php echo $order['order_number']; ?></p>
                </div>
                
                <div class="invoice-info">
                    <div class="info-box">
                        <strong>Bill To:</strong><br>
                        <?php echo htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username']); ?><br>
                        <?php echo nl2br(htmlspecialchars($order['shipping_address'])); ?><br>
                        Phone: <?php echo htmlspecialchars($order['phone']); ?>
                    </div>
                    <div class="info-box">
                        <strong>Payment Method:</strong><br>
                        <?php echo $order['payment_method']; ?><br>
                        <strong>Status:</strong> <span class="status-pending">Pending</span>
                    </div>
                </div>
                
                <table class="invoice-table">
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th>Qty</th>
                            <th>Price</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($detail = $details->fetch_assoc()): ?>
                        <tr>
                            <td>
                                <?php echo htmlspecialchars($detail['book_title']); ?><br>
                                <small><?php echo htmlspecialchars($detail['book_author']); ?></small>
                            </td>
                            <td><?php echo $detail['quantity']; ?></td>
                            <td>Rp <?php echo number_format($detail['price'], 0, ',', '.'); ?></td>
                            <td>Rp <?php echo number_format($detail['subtotal'], 0, ',', '.'); ?></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
                
                <div class="invoice-total">
                    <div class="total-row">
                        <span>Subtotal</span>
                        <span>Rp <?php echo number_format($order['total_amount'], 0, ',', '.'); ?></span>
                    </div>
                    <div class="total-row">
                        <span>Shipping</span>
                        <span>Rp <?php echo number_format($order['shipping_cost'], 0, ',', '.'); ?></span>
                    </div>
                    <div class="total-row grand">
                        <span>TOTAL</span>
                        <span>Rp <?php echo number_format($order['grand_total'], 0, ',', '.'); ?></span>
                    </div>
                </div>
                
                <div class="invoice-footer">
                    <p>Thank you for shopping at BookStore!</p>
                    <p class="small">This invoice is generated automatically. Please keep this for your records.</p>
                </div>
                
                <div class="invoice-actions">
                    <button onclick="window.print()" class="btn-print">🖨️ Print Invoice</button>
                    <a href="index.php" class="btn-home-invoice">🏠 Back to Home</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>